"""文本主观题：结构化评分点 + 语义匹配 + 规则拦截。"""

from __future__ import annotations

import re
import unicodedata
from collections import OrderedDict
from collections.abc import Sequence
from dataclasses import dataclass, field
from threading import RLock

from subjective_scoring.engines.calibration import (
    ScoreCalibrator,
    calibrator_for_backend,
    default_calibrator_for_backend,
)
from subjective_scoring.engines._similarity import (
    DocumentBatchScorer,
    PairScorer,
    SimilarityFn,
    lexical_similarity,
    resolve_pair_scorer,
    tokenize,
)
from subjective_scoring.engines.entities import (
    build_point_entity_profile,
    has_cjk,
    student_entity_view,
)
from subjective_scoring.models import (
    EvidenceItem,
    IntermediateScoreResult,
    PointConflictPolicy,
    PointRelation,
    ScoringMode,
    ScoringPoint,
    ScoringRequest,
)

_DEFAULT_MATCH_THRESHOLD = 0.55
_EXACT_MATCH_WHITESPACE_RE = re.compile(r"\s+")
_EXACT_MATCH_PUNCTUATION = str.maketrans(
    {
        "，": ",",
        "。": ".",
        "、": ",",
        "；": ";",
        "：": ":",
        "！": "!",
        "？": "?",
        "“": '"',
        "”": '"',
        "‘": "'",
        "’": "'",
        "（": "(",
        "）": ")",
        "【": "[",
        "】": "]",
        "…": "...",
        "—": "-",
        "–": "-",
    }
)
_NEGATION_RE = re.compile(
    r"(并非是|无法|不能|不会|不可|没有|不是|并非|尚未"
    r"|无(?![法限论需效辜聊奈恙缘比偿状态线数条件])"
    r"|非(?![常凡洲法正式同])"
    r"|未(?![来必知遂])"
    r"|不(?![同过管仅然料断足堪屑可论如低符超及良佳逊亚足])"
    r"|没"
    r"|never|not|no|without|cannot|can't|won't)",
    re.IGNORECASE,
)
_NUMBER_RE = re.compile(
    r"-?\d+(?:\.\d+)?%?",
)
_UNIT_RE = re.compile(
    r"(ms|s|秒|分钟|小时|天|%|％|倍|次|个|条|行|列|mb|gb|kb"
    r"|MPa|kPa|Pa|pa|V|A|W|kW|kV|mA|mV"
    r"|Hz|kHz|MHz|rpm|r/min|N"
    r"|mm|cm|m|km|kg|g|t|L|ml|mah|mAh"
    r"|MB|GB|KB)",
    re.IGNORECASE,
)
_DIRECTION_PAIRS = (
    ("提高", "降低"),
    ("增加", "减少"),
    ("上升", "下降"),
    ("大于", "小于"),
    (">", "<"),
    (">=", "<="),
    ("left", "right"),
    ("升序", "降序"),
    ("正向", "反向"),
)


def _normalize_exact_match_text(text: str) -> str:
    normalized = unicodedata.normalize("NFKC", str(text or ""))
    normalized = normalized.casefold().translate(_EXACT_MATCH_PUNCTUATION)
    return _EXACT_MATCH_WHITESPACE_RE.sub(" ", normalized).strip()
_ANTONYM_PAIRS = (
    ("正确", "错误"),
    ("成功", "失败"),
    ("同步", "异步"),
    ("静态", "动态"),
    ("开启", "关闭"),
    ("允许", "禁止"),
)
_CLAUSE_RE = re.compile(r"[。！？!?；;，,\n]+")
_STOPWORDS = set(tokenize("的 了 和 与 或 是 在 为 等 及 使用 通过 可以 应该 保持"))
_DEFAULT_POLARITY_RULES = (
    (
        "stateless",
        r"(无状态|不保存.{0,10}(会话|客户端状态)|不依赖.{0,10}(历史|上下文|会话))",
        r"(有状态|保存.{0,8}(客户端)?会话状态|依赖.{0,8}(历史|上下文|会话))",
    ),
)


@dataclass
class ResolvedScoringPoint:
    id: str
    text: str
    score: float
    required: bool = False
    critical: bool = False
    conflict_policy: PointConflictPolicy = PointConflictPolicy.POINT_ZERO
    conflict_score_cap_ratio: float = 0.4
    synthetic: bool = False


@dataclass(frozen=True)
class PointEvidenceMatch:
    evidence: str
    raw_similarity: float
    whole_answer_similarity: float
    candidate_count: int


@dataclass
class RuleHit:
    point_id: str
    kind: str
    message: str
    severity: str = "hard"
    evidence: str | None = None
    confidence: float = 1.0


@dataclass
class RuleInterceptResult:
    hits: list[RuleHit] = field(default_factory=list)

    @property
    def hard_hits(self) -> list[RuleHit]:
        return [h for h in self.hits if h.severity == "hard"]


class ScoringPointResolver:
    """人工评分点优先；否则标准答案全文兜底（可标记强制复核）。"""

    def resolve(self, request: ScoringRequest) -> tuple[list[ResolvedScoringPoint], list[str], bool]:
        warnings: list[str] = []
        force_review = False

        if request.scoring_points:
            points = [
                ResolvedScoringPoint(
                    id=p.id,
                    text=p.text,
                    score=float(p.score),
                    required=p.required,
                    critical=p.critical,
                    conflict_policy=p.conflict_policy,
                    conflict_score_cap_ratio=p.conflict_score_cap_ratio,
                )
                for p in request.scoring_points
            ]
            return points, warnings, force_review

        ref = (request.reference_answer or "").strip()
        if ref:
            warnings.append("未配置 scoring_points，使用 reference_answer 全文兜底")
            force_review = True
            return (
                [
                    ResolvedScoringPoint(
                        id="__full_reference__",
                        text=ref,
                        score=float(request.max_score),
                        required=True,
                        synthetic=True,
                    )
                ],
                warnings,
                force_review,
            )

        if request.scoring_config.allow_auto_scoring_point_generation:
            warnings.append(
                "allow_auto_scoring_point_generation=true 但第一版未实现自动生成评分点"
            )
        warnings.append("无评分点且无标准答案，文本评分无法进行")
        force_review = True
        return [], warnings, force_review


class RuleInterceptor:
    """轻量规则拦截：否定、数字、单位、方向、反义。"""

    def __init__(
        self,
        polarity_rules: Sequence[tuple[str, str, str]] | None = None,
    ) -> None:
        rules = [*_DEFAULT_POLARITY_RULES, *(polarity_rules or ())]
        self.polarity_rules = [
            (name, re.compile(positive, re.IGNORECASE), re.compile(negative, re.IGNORECASE))
            for name, positive, negative in rules
        ]

    def check(self, point_text: str, student_answer: str, point_id: str) -> RuleInterceptResult:
        hits: list[RuleHit] = []
        pt = point_text or ""
        sa = student_answer or ""

        negation_conflict, negation_evidence, negation_confidence = (
            self._negation_conflict(pt, sa)
        )
        if negation_conflict:
            hits.append(
                RuleHit(
                    point_id=point_id,
                    kind="negation",
                    message=f"否定词冲突：评分点与学生答案极性相反（{point_id}）",
                    severity="hard",
                    evidence=negation_evidence,
                    confidence=negation_confidence,
                )
            )

        if self._number_mismatch(pt, sa):
            hits.append(
                RuleHit(
                    point_id=point_id,
                    kind="number",
                    message=f"数字不一致：评分点中的关键数字未在学生答案中出现（{point_id}）",
                    severity="hard",
                )
            )

        if self._unit_mismatch(pt, sa):
            hits.append(
                RuleHit(
                    point_id=point_id,
                    kind="unit",
                    message=f"单位不一致：评分点单位与学生答案不匹配（{point_id}）",
                    severity="soft",
                )
            )

        if self._direction_conflict(pt, sa):
            hits.append(
                RuleHit(
                    point_id=point_id,
                    kind="direction",
                    message=f"方向词冲突：提高/降低等方向相反（{point_id}）",
                    severity="hard",
                )
            )

        if self._antonym_conflict(pt, sa):
            hits.append(
                RuleHit(
                    point_id=point_id,
                    kind="antonym",
                    message=f"反义词冲突：关键对立概念不一致（{point_id}）",
                    severity="soft",
                )
            )

        return RuleInterceptResult(hits=hits)

    @staticmethod
    def _has_negation(text: str) -> bool:
        return bool(_NEGATION_RE.search(text or ""))

    def _negation_conflict(self, point: str, student: str) -> tuple[bool, str | None, float]:
        """只在与评分点局部相关的语句中判断极性。"""

        point_polarity = self._concept_polarity(point)
        point_tokens = self._content_tokens(point)
        candidates: list[tuple[int, str]] = []
        for clause in _CLAUSE_RE.split(student or ""):
            clause = clause.strip()
            if not clause:
                continue
            overlap = len(point_tokens & self._content_tokens(clause))
            if overlap:
                candidates.append((overlap, clause))

        if not candidates:
            return False, None, 0.0

        for overlap, clause in sorted(candidates, reverse=True):
            clause_polarity = self._concept_polarity(clause)
            if point_polarity and clause_polarity and point_polarity[0] == clause_polarity[0]:
                if point_polarity[1] != clause_polarity[1]:
                    return True, clause, 1.0
                # 极性名称和值都相同 → 语义一致（_concept_polarity 已处理否定词翻转）
                continue

            point_negated = self._has_negation(point)
            clause_negated = self._has_negation(clause)
            if point_negated == clause_negated:
                continue
            # 评分点本身为否定命题时，证据片段没有重复否定词只代表信息不完整，
            # 不能据此推断学生明确给出了相反结论。领域极性规则已在上方处理
            # “无状态/有状态”等显式对立。
            if point_negated and not clause_negated:
                continue
            # 单个宽泛 token 容易把别处的否定词错误关联到评分点。
            # 需要较高重叠才判定，避免"不保存会话状态"与"无状态协议"误判
            if overlap >= 4 or any(
                len(token) >= 4 and token in clause for token in point_tokens
            ):
                confidence = min(1.0, 0.55 + overlap * 0.15)
                return True, clause, confidence
        return False, None, 0.0

    @staticmethod
    def _content_tokens(text: str) -> set[str]:
        return {token for token in tokenize(text or "") if token not in _STOPWORDS}

    def _concept_polarity(self, text: str) -> tuple[str, int] | None:
        value = text or ""
        for name, positive, negative in self.polarity_rules:
            m = positive.search(value)
            if m:
                # 检查匹配前是否有否定词（如"不是无状态"中"不是"在"无状态"之前）
                # 仅当否定词在匹配范围之外时翻转极性
                before = value[max(0, m.start() - 4):m.start()]
                if before and _NEGATION_RE.search(before):
                    return name, -1
                return name, 1
            m = negative.search(value)
            if m:
                before = value[max(0, m.start() - 4):m.start()]
                if before and _NEGATION_RE.search(before):
                    return name, 1
                return name, -1
        return None

    @staticmethod
    def _extract_numbers(text: str) -> set[str]:
        return {m.group(0).lower() for m in _NUMBER_RE.finditer(text or "")}

    def _number_mismatch(self, point: str, student: str) -> bool:
        pn = self._extract_numbers(point)
        if not pn:
            return False
        # 纯数字评分点（如 max_score 作兜底文本 "10"）不触发数字不匹配：
        # 这是自动生成的代理文本，数字本身无语义约束。
        if len(pn) == 1 and len(point.strip()) <= 6:
            return False
        sn = self._extract_numbers(student)
        return bool(sn) and pn.isdisjoint(sn)

    @staticmethod
    def _unit_matches(text: str) -> set[str]:
        """提取文本中的单位，但过滤掉非计量语境下的单字母标记。

        单字母单位（A/V/W/m 等）在文本中可能是分类标记（A类、B档）
        而非计量单位；只有前面有数字时才视为真单位。
        """
        units = set()
        for m in _UNIT_RE.finditer(text or ""):
            val = m.group(0).lower()
            # 多字母单位或汉字单位：直接纳入
            if len(val) > 1:
                units.add(val)
                continue
            # 单字母单位：要求前面有数字才视为真计量单位
            # （避免 "A 类" / "B 档" / "C 级" 中的分类字母被误认为安培/伏特等）
            before = text[max(0, m.start() - 2) : m.start()]
            if any(c.isdigit() for c in before):
                units.add(val)
        return units

    def _unit_mismatch(self, point: str, student: str) -> bool:
        # “行/列/次”等汉字在普通词语中很常见；只有评分点明确包含数字时，
        # 才将其解释为需要严格核对的计量单位。
        if not self._extract_numbers(point):
            return False
        # 纯数字评分点（max_score 兜底）不触发单位检测
        if len(self._extract_numbers(point)) == 1 and len(point.strip()) <= 6:
            return False
        pu = self._unit_matches(point)
        if not pu:
            return False
        su = self._unit_matches(student)
        return not pu.intersection(su)

    def _direction_conflict(self, point: str, student: str) -> bool:
        pl, sl = (point or "").lower(), (student or "").lower()
        for a, b in _DIRECTION_PAIRS:
            if (a in pl and b in sl) or (b in pl and a in sl):
                # 两边各自只含对立一侧
                if not (a in pl and b in pl) and not (a in sl and b in sl):
                    return True
        return False

    def _antonym_conflict(self, point: str, student: str) -> bool:
        pl, sl = point or "", student or ""
        for a, b in _ANTONYM_PAIRS:
            if (a in pl and b in sl) or (b in pl and a in sl):
                if not (a in pl and b in pl) and not (a in sl and b in sl):
                    return True
        return False


class TextRerankerScorer:
    """文本题评分引擎。

    Parameters
    ----------
    pair_scorer:
        可注入的成对打分器或 (query, doc) -> float，便于测试。
    match_threshold:
        可选的支持阈值覆盖；未传入时使用请求中的 text_relation_thresholds.support。
    allow_model_load:
        False 时不尝试加载 BGE/CrossEncoder（单元测试默认）。
    model_name:
        默认 BAAI/bge-reranker-base。
    """

    name = "TextRerankerScorer"

    def __init__(
        self,
        *,
        pair_scorer: PairScorer | SimilarityFn | None = None,
        match_threshold: float | None = None,
        allow_model_load: bool = True,
        model_name: str = "BAAI/bge-reranker-base",
        point_resolver: ScoringPointResolver | None = None,
        rule_interceptor: RuleInterceptor | None = None,
        calibrator: ScoreCalibrator | None = None,
        reference_cache_size: int = 256,
    ) -> None:
        if reference_cache_size < 0:
            raise ValueError("reference_cache_size must not be negative")
        self._injected = pair_scorer
        self.match_threshold = match_threshold
        self.allow_model_load = allow_model_load
        self.model_name = model_name
        self.point_resolver = point_resolver or ScoringPointResolver()
        self.rule_interceptor = rule_interceptor or RuleInterceptor()
        self.calibrator = calibrator
        self.reference_cache_size = reference_cache_size
        self._reference_match_cache: OrderedDict[
            tuple[object, ...], tuple[PointEvidenceMatch, ...]
        ] = OrderedDict()
        self._reference_cache_lock = RLock()

    def _support_threshold_for_backend(
        self,
        request: ScoringRequest,
        backend_name: str,
    ) -> float:
        options = request.scoring_config.text_relation_thresholds
        if self.match_threshold is not None:
            return self.match_threshold
        # 显式配置 support 时维持 v0.1.3 的全后端覆盖语义。
        if "support" in options.model_fields_set:
            return options.support
        if backend_name == "lexical_fallback":
            return options.lexical_fallback_support
        if backend_name.startswith("cohere:"):
            return options.remote_reranker_support
        return options.local_cross_encoder_support

    @staticmethod
    def _evidence_candidates(answer: str) -> list[str]:
        value = (answer or "").strip()
        if not value:
            return []
        clauses = [
            clause.strip()
            for clause in _CLAUSE_RE.split(value)
            if clause.strip()
        ]
        windows = [
            "，".join(clauses[index : index + size])
            for size in (2, 3)
            for index in range(max(0, len(clauses) - size + 1))
        ]
        candidates: list[str] = []
        for candidate in [*clauses, *windows, value]:
            if candidate and candidate not in candidates:
                candidates.append(candidate)
        return candidates

    @staticmethod
    def _best_evidence_match(
        answer: str,
        candidates: list[str],
        scores: Sequence[float],
    ) -> PointEvidenceMatch:
        if not candidates:
            return PointEvidenceMatch("", 0.0, 0.0, 0)
        values = [float(score) for score in scores[: len(candidates)]]
        if len(values) < len(candidates):
            values.extend([0.0] * (len(candidates) - len(values)))
        best_index = max(range(len(candidates)), key=values.__getitem__)
        whole_index = candidates.index((answer or "").strip())
        return PointEvidenceMatch(
            evidence=candidates[best_index],
            raw_similarity=values[best_index],
            whole_answer_similarity=values[whole_index],
            candidate_count=len(candidates),
        )

    def _score_evidence_sets(
        self,
        scorer: PairScorer,
        answers: Sequence[str],
        points: list[ResolvedScoringPoint],
    ) -> list[list[PointEvidenceMatch]]:
        candidate_sets = [self._evidence_candidates(answer) for answer in answers]
        matches = [
            [PointEvidenceMatch("", 0.0, 0.0, 0) for _point in points]
            for _answer in answers
        ]

        if isinstance(scorer, DocumentBatchScorer):
            for point_index, point in enumerate(points):
                documents = [
                    candidate
                    for candidates in candidate_sets
                    for candidate in candidates
                ]
                if not documents:
                    continue
                document_scores = scorer.score_documents(point.text, documents)
                offset = 0
                for answer_index, candidates in enumerate(candidate_sets):
                    end = offset + len(candidates)
                    matches[answer_index][point_index] = self._best_evidence_match(
                        answers[answer_index],
                        candidates,
                        document_scores[offset:end],
                    )
                    offset = end
            return matches

        for answer_index, (answer, candidates) in enumerate(
            zip(answers, candidate_sets)
        ):
            if not candidates:
                continue
            pairs = [
                (candidate, point.text)
                for point in points
                for candidate in candidates
            ]
            scores = [float(score) for score in scorer.score_pairs(pairs)]
            candidate_count = len(candidates)
            for point_index, _point in enumerate(points):
                start = point_index * candidate_count
                end = start + candidate_count
                matches[answer_index][point_index] = self._best_evidence_match(
                    answer,
                    candidates,
                    scores[start:end],
                )
        return matches

    def _score_evidence_matches(
        self,
        scorer: PairScorer,
        answer: str,
        points: list[ResolvedScoringPoint],
    ) -> list[PointEvidenceMatch]:
        return self._score_evidence_sets(scorer, [answer], points)[0]

    @staticmethod
    def _reference_cache_key(
        backend_name: str,
        reference: str,
        points: list[ResolvedScoringPoint],
    ) -> tuple[object, ...]:
        return (
            backend_name,
            reference,
            tuple(
                (point.id, point.text, point.required, point.critical)
                for point in points
            ),
        )

    def _get_cached_reference_matches(
        self,
        key: tuple[object, ...],
    ) -> list[PointEvidenceMatch] | None:
        if self.reference_cache_size == 0:
            return None
        with self._reference_cache_lock:
            cached = self._reference_match_cache.get(key)
            if cached is None:
                return None
            self._reference_match_cache.move_to_end(key)
            return list(cached)

    def _cache_reference_matches(
        self,
        key: tuple[object, ...],
        matches: list[PointEvidenceMatch],
    ) -> None:
        if self.reference_cache_size == 0:
            return
        with self._reference_cache_lock:
            self._reference_match_cache[key] = tuple(matches)
            self._reference_match_cache.move_to_end(key)
            while len(self._reference_match_cache) > self.reference_cache_size:
                self._reference_match_cache.popitem(last=False)

    def score(self, request: ScoringRequest) -> IntermediateScoreResult:
        raw_student = request.student_answer or ""
        reference = request.reference_answer or ""
        if not raw_student.strip():
            return IntermediateScoreResult(
                scorer=self.name,
                scoring_mode=ScoringMode.TEXT,
                score=0.0,
                max_score=request.max_score,
                confidence=1.0,
                metadata={
                    "model": None,
                    "parser": None,
                    "decision": "auto_zero",
                    "decision_reason": "blank_answer",
                    "deterministic": True,
                    "point_count": len(request.scoring_points),
                    "relation_counts": {
                        "supported": 0,
                        "contradicted": 0,
                        "unknown": 0,
                    },
                },
            )

        normalized_reference = _normalize_exact_match_text(reference)
        if (
            normalized_reference
            and _normalize_exact_match_text(raw_student) == normalized_reference
        ):
            return IntermediateScoreResult(
                scorer=self.name,
                scoring_mode=ScoringMode.TEXT,
                score=request.max_score,
                max_score=request.max_score,
                confidence=1.0,
                metadata={
                    "model": None,
                    "parser": None,
                    "decision": "auto_score",
                    "decision_reason": "exact_reference_match",
                    "deterministic": True,
                    "point_count": len(request.scoring_points),
                    "relation_counts": {
                        "supported": len(request.scoring_points),
                        "contradicted": 0,
                        "unknown": 0,
                    },
                },
            )

        points, warnings, force_review = self.point_resolver.resolve(request)
        student = raw_student.strip()
        precision = request.scoring_config.score_precision
        relation_options = request.scoring_config.text_relation_thresholds
        conflict_threshold = relation_options.conflict
        corrections = request.scoring_config.text_bounded_corrections

        if not points:
            return IntermediateScoreResult(
                scorer=self.name,
                scoring_mode=ScoringMode.TEXT,
                score=0.0,
                max_score=request.max_score,
                confidence=0.0,
                warnings=warnings,
                force_manual_review=True,
                metadata={"model": None, "parser": None},
            )

        scorer, backend_name = resolve_pair_scorer(
            prefer_model=self.model_name,
            injected=self._injected,
            allow_model_load=self.allow_model_load,
        )
        if backend_name == "lexical_fallback":
            warnings.append("语义模型不可用，已回退到词法相似度")

        support_threshold = self._support_threshold_for_backend(request, backend_name)
        request_calibration_points = request.scoring_config.calibration_points
        if request_calibration_points is not None:
            calibrator = calibrator_for_backend(
                backend_name,
                request_calibration_points,
            )
        else:
            calibrator = self.calibrator or default_calibrator_for_backend(backend_name)
        reference = reference.strip()
        reference_matches: list[PointEvidenceMatch] | None = None
        reference_cache_hit = False
        if relation_options.validate_reference_points and reference:
            reference_cache_key = self._reference_cache_key(
                backend_name,
                reference,
                points,
            )
            reference_matches = self._get_cached_reference_matches(
                reference_cache_key
            )
            if reference_matches is not None:
                reference_cache_hit = True
                student_matches = self._score_evidence_matches(
                    scorer,
                    student,
                    points,
                )
            else:
                student_matches, reference_matches = self._score_evidence_sets(
                    scorer,
                    [student, reference],
                    points,
                )
                self._cache_reference_matches(
                    reference_cache_key,
                    reference_matches,
                )
        else:
            student_matches = self._score_evidence_matches(
                scorer,
                student,
                points,
            )

        matched: list[EvidenceItem] = []
        missed: list[EvidenceItem] = []
        total = 0.0
        weighted_conf = 0.0
        weight_sum = 0.0
        hard_conflict = False
        supported_count = 0
        contradicted_count = 0
        unknown_count = 0
        required_unknown = False
        total_conflict_zero = False
        total_conflict_cap_ratio = 1.0
        applied_caps: list[str] = []
        decision_reason: str | None = None
        provisional_total = 0.0
        rubric_diagnostics: list[dict[str, object]] = []
        point_diagnostics: list[dict[str, object]] = []

        # 有界修正共享的实体档案：合成兜底点与非中文评分点不参与
        # （实体启发式面向中文语料，兜底点文本是整篇标准答案）
        entity_profiles = [
            None
            if point.synthetic or not has_cjk(point.text)
            else build_point_entity_profile(
                point.text,
                request.question,
                corrections.extra_equivalences,
            )
            for point in points
        ]
        student_entity_text, student_number_variants = student_entity_view(student)
        entity_hit_list = [
            profile.match(student_entity_text, student_number_variants)
            if profile is not None
            else None
            for profile in entity_profiles
        ]
        # 套话签名 = 整卷零命中：改述型答案总会在某个评分点命中实体，
        # 只有对所有评分点都零命中的答案才进入门槛压分。
        answer_zero_entity_hits = all(
            hits.total == 0 for hits in entity_hit_list if hits is not None
        )
        # 题干复述检测：答案只命中了题干中已存在的术语（如复述题干关键词），
        # 但未命中任何评分点独有实体——空泛套话只会抄题干词，没有实质内容。
        # 仅当不是整卷零命中（否则已由 answer_zero_entity_hits 覆盖）时才触发。
        answer_stem_only_hits = (
            not answer_zero_entity_hits
            and all(
                hits.exclusive_hits == 0
                for hits in entity_hit_list
                if hits is not None
            )
        )
        answer_entity_pool = sum(
            profile.entity_count
            for profile in entity_profiles
            if profile is not None
        )
        gated_points: list[str] = []
        floored_points: list[dict[str, str]] = []

        if reference_matches is not None:
            for point, reference_match in zip(points, reference_matches):
                if not (point.required or point.critical):
                    continue
                reference_raw = float(
                    max(0.0, min(1.0, reference_match.raw_similarity))
                )
                reference_sim = float(
                    max(0.0, min(1.0, calibrator.calibrate(reference_raw)))
                )
                reference_rule = self.rule_interceptor.check(
                    point.text,
                    reference_match.evidence,
                    point.id,
                )
                reference_conflict = any(
                    hit.confidence >= conflict_threshold
                    for hit in reference_rule.hard_hits
                )
                reference_supported = (
                    reference_sim >= support_threshold and not reference_conflict
                )
                rubric_diagnostics.append(
                    {
                        "point_id": point.id,
                        "supported": reference_supported,
                        "raw_similarity": round(reference_raw, 4),
                        "calibrated_similarity": round(reference_sim, 4),
                        "evidence": reference_match.evidence,
                        "hard_conflict": reference_conflict,
                    }
                )
                if not reference_supported:
                    force_review = True
                    decision_reason = "rubric_self_check_failed"
                    warnings.append(
                        f"评分表自检失败：标准答案未可靠支持必答或关键评分点 {point.id}"
                    )

        for point_index, (point, evidence_match) in enumerate(
            zip(points, student_matches)
        ):
            raw_sim = float(
                max(0.0, min(1.0, evidence_match.raw_similarity))
            )
            calibrated_sim = float(
                max(0.0, min(1.0, calibrator.calibrate(raw_sim)))
            )
            rule = self.rule_interceptor.check(
                point.text,
                evidence_match.evidence,
                point.id,
            )
            confident_hard_hits = [
                hit for hit in rule.hard_hits if hit.confidence >= conflict_threshold
            ]
            uncertain_hard_hits = [
                hit for hit in rule.hard_hits if hit.confidence < conflict_threshold
            ]

            # 保底修正：只抬相似度，且要求关键实体命中、无任何规则冲突。
            # 实体命中检测基于学生答案全文，而非最佳句段。
            profile = entity_profiles[point_index]
            entity_hits = entity_hit_list[point_index]
            correction_applied: str | None = None
            if profile is not None and entity_hits is not None and not rule.hits:
                if (
                    corrections.enable_numeric_floor
                    and profile.primarily_numeric
                    and entity_hits.informative_numbers_complete
                    and corrections.numeric_floor_similarity > calibrated_sim
                ):
                    calibrated_sim = corrections.numeric_floor_similarity
                    correction_applied = "numeric_floor"
                elif (
                    corrections.enable_short_answer_floor
                    and len(student) <= corrections.short_answer_max_chars
                    and entity_hits.entity_total > 0
                    and entity_hits.numbers_complete
                    and entity_hits.coverage
                    >= corrections.short_answer_term_coverage
                    and corrections.short_answer_similarity_floor > calibrated_sim
                ):
                    calibrated_sim = corrections.short_answer_similarity_floor
                    correction_applied = "short_answer_floor"
                if correction_applied is not None:
                    floored_points.append(
                        {"point_id": point.id, "kind": correction_applied}
                    )

            # 套话签名（点级），0.85 满分通道与实体门槛共用：
            # - _stem_only：整卷只命中题干已有术语，未命中任何评分点独有实体；
            # - _platitude_short：短答案 + 相似度虚高 + 独有实体零命中 + 覆盖率过低。
            # exclusive_hits > 0 说明命中了评分点独有的内容，不应判定为套话。
            _stem_only = (
                answer_stem_only_hits
                and entity_hits is not None
                and entity_hits.exclusive_hits == 0
            )
            _platitude_short = (
                len(student) <= 80
                and profile is not None
                and entity_hits is not None
                and entity_hits.entity_total > 0
                and calibrated_sim >= 0.95
                and entity_hits.exclusive_hits == 0
                and entity_hits.total / entity_hits.entity_total <= 0.3
            )

            if confident_hard_hits:
                relation = PointRelation.CONTRADICTED
                relation_confidence = max(hit.confidence for hit in confident_hard_hits)
            elif uncertain_hard_hits:
                relation = PointRelation.UNKNOWN
                relation_confidence = max(hit.confidence for hit in uncertain_hard_hits)
            elif calibrated_sim >= support_threshold:
                relation = PointRelation.SUPPORTED
                relation_confidence = calibrated_sim
            else:
                relation = PointRelation.UNKNOWN
                relation_confidence = max(0.0, 1.0 - calibrated_sim)

            point_score = 0.0
            point_provisional_score = 0.0
            adjusted_confidence = relation_confidence
            reason_parts = [
                f"原始相关度 {raw_sim:.2f}",
                f"校准覆盖度 {calibrated_sim:.2f}",
                f"关系 {relation.value}",
            ]
            if correction_applied == "numeric_floor":
                reason_parts.append(
                    "数值保底：关键数值全部命中且非题干抄写，相似度抬升至 "
                    f"{corrections.numeric_floor_similarity:.2f}"
                )
            elif correction_applied == "short_answer_floor":
                reason_parts.append(
                    "短答案保底：实体覆盖率达标，相似度抬升至 "
                    f"{corrections.short_answer_similarity_floor:.2f}"
                )

            if rule.hits:
                for hit in rule.hits:
                    warnings.append(hit.message)
                    reason_parts.append(hit.message)

            if relation == PointRelation.SUPPORTED:
                supported_count += 1
                # 0.85 满分通道的实体前置条件：相似度再高，套话签名存在时
                # 也不给满分——整卷零命中、只命中题干术语、或短答案 + 虚高
                # 相似度 + 独有实体零命中（覆盖率≤0.3）。与实体门槛共用同一
                # 套话判定；区别是这里只阻止满分通道，不额外压分（套话仍拿到
                # calibrated_sim * score 的残余分）。
                # 不按覆盖率比例拦截：改述型答案常因同义表述未命中全部实体
                # （如 1/2），但整卷已命中关键实体即视为实质作答，交给语义
                # 相似度判断（等价表/语义覆盖见 test_entity_gate_spares_*）。
                # entity_gate_min_entities 不限制此处——任何有实体的评分点都
                # 应防止套话用纯语义相似度拿到满分。
                _full_mark_blocked = (
                    calibrated_sim >= 0.85
                    and profile is not None
                    and entity_hits is not None
                    and corrections.enable_entity_gate
                    and (
                        (answer_zero_entity_hits and entity_hits.total == 0)
                        or _stem_only
                        or _platitude_short
                    )
                )
                if _full_mark_blocked:
                    point_score = calibrated_sim * point.score
                else:
                    point_score = (
                        point.score
                        if calibrated_sim >= 0.85
                        else calibrated_sim * point.score
                    )
                soft_hits = [hit for hit in rule.hits if hit.severity != "hard"]
                if soft_hits:
                    point_score *= 0.65
                    adjusted_confidence = calibrated_sim * 0.8
                point_provisional_score = point_score
            elif relation == PointRelation.CONTRADICTED:
                contradicted_count += 1
                hard_conflict = True
                force_review = True
                adjusted_confidence = min(relation_confidence, 0.4)
                if point.conflict_policy == PointConflictPolicy.ZERO_TOTAL:
                    total_conflict_zero = True
                elif point.conflict_policy == PointConflictPolicy.CAP_TOTAL:
                    total_conflict_cap_ratio = min(
                        total_conflict_cap_ratio,
                        point.conflict_score_cap_ratio,
                    )
            else:
                unknown_count += 1
                point_provisional_score = calibrated_sim * point.score
                if uncertain_hard_hits:
                    point_provisional_score *= 0.35
                elif any(hit.severity != "hard" for hit in rule.hits):
                    point_provisional_score *= 0.65
                # 当允许无 supported 点时自动定分，用 provisional 值参与计分
                if not relation_options.reject_when_no_supported:
                    point_score = point_provisional_score
                if point.required or point.critical:
                    required_unknown = True
                # 未拆分全文仅用于兼容兜底估分，始终要求人工复核。
                if point.synthetic and not relation_options.apply_gate_to_synthetic_reference:
                    force_review = True
                    reason_parts.append("全文兜底点未应用原子评分门槛，仅作待复核估分")

            # 实体门槛：句段相似度再高，整卷关键实体零命中也按系数压分（套话拦截）。
            # 与保底互斥——保底触发意味着实体命中，此处必然不触发。
            # 套话判定与 0.85 满分通道共用（_stem_only / _platitude_short）：
            # - 题干复述：答案只命中了题干已出现的术语，未命中评分点独有实体；
            # - 短答案套话签名：答案很短（< 80 字）且相似度虚高（>= 0.95）时，
            #   即使通过等价表泛词命中了少数实体，只要独有实体完全未命中
            #   （exclusive_hits == 0）且覆盖率不超过 30%，仍视为套话并压分。
            # 注意：exclusive_hits > 0 意味着命中了评分点独有的内容，不应压分。
            # 阈值从 0.5 降至 0.3 降低对正确短答案的误伤。
            entity_gated = False
            if (
                profile is not None
                and entity_hits is not None
                and corrections.enable_entity_gate
                and (answer_zero_entity_hits or _stem_only or _platitude_short)
                and relation is not PointRelation.CONTRADICTED
                and (
                    profile.entity_count >= corrections.entity_gate_min_entities
                    or answer_entity_pool
                    >= corrections.entity_gate_min_answer_entities
                )
                and (entity_hits.total == 0 or _stem_only or _platitude_short)
            ):
                entity_gated = True
                gated_points.append(point.id)
                point_score *= corrections.entity_gate_ratio
                point_provisional_score *= corrections.entity_gate_ratio
                relation_confidence = min(relation_confidence, 0.5)
                adjusted_confidence = min(adjusted_confidence, 0.5)
                if answer_zero_entity_hits:
                    gate_message = (
                        f"实体门槛：答案未命中评分点 {point.id} 的任何关键实体"
                        f"（术语/数值），得分按 {corrections.entity_gate_ratio:g} 折算"
                    )
                elif _platitude_short:
                    gate_message = (
                        f"套话签名：答案极短（{len(student)} 字）但相似度极高"
                        f"（{calibrated_sim:.2f}），未覆盖评分点 {point.id} 的独有内容，"
                        f"得分按 {corrections.entity_gate_ratio:g} 折算"
                    )
                else:
                    gate_message = (
                        f"题干复述检测：答案仅命中题干已有术语，未覆盖评分点"
                        f" {point.id} 的独有内容，得分按 {corrections.entity_gate_ratio:g} 折算"
                    )
                warnings.append(gate_message)
                reason_parts.append(gate_message)

            point_diagnostics.append(
                {
                    "point_id": point.id,
                    "raw_similarity": round(raw_sim, 4),
                    "calibrated_similarity": round(calibrated_sim, 4),
                    "whole_answer_similarity": round(
                        max(0.0, min(1.0, evidence_match.whole_answer_similarity)),
                        4,
                    ),
                    "evidence": evidence_match.evidence,
                    "candidate_count": evidence_match.candidate_count,
                    "adjusted_confidence": round(adjusted_confidence, 4),
                    "relation": relation.value,
                    "relation_confidence": round(relation_confidence, 4),
                    "synthetic": point.synthetic,
                    "entity_count": profile.entity_count if profile else 0,
                    "entity_hit_count": entity_hits.total if entity_hits else None,
                    "entity_gate": entity_gated,
                    "bounded_correction": correction_applied,
                    "rule_hits": [
                        {
                            "kind": hit.kind,
                            "severity": hit.severity,
                            "confidence": round(hit.confidence, 4),
                            "evidence": hit.evidence,
                        }
                        for hit in rule.hits
                    ],
                }
            )

            point_score = round(min(point_score, point.score), precision)
            point_provisional_score = round(
                min(point_provisional_score, point.score),
                precision,
            )
            total += point_score
            provisional_total += point_provisional_score
            weighted_conf += relation_confidence * point.score
            weight_sum += point.score

            evidence = EvidenceItem(
                point_id=point.id,
                score=point_score,
                provisional_score=point_provisional_score,
                max_score=point.score,
                evidence=evidence_match.evidence or None,
                reason="；".join(reason_parts),
                similarity=round(calibrated_sim, 4),
                relation=relation,
                relation_confidence=round(relation_confidence, 4),
            )
            if relation == PointRelation.SUPPORTED:
                matched.append(evidence)
            else:
                missed.append(
                    EvidenceItem(
                        point_id=point.id,
                        score=point_score,
                        provisional_score=point_provisional_score,
                        max_score=point.score,
                        reason=evidence.reason
                        if rule.hits
                        else f"未充分覆盖评分点：{point.text}",
                        similarity=round(calibrated_sim, 4),
                        evidence=evidence_match.evidence or None,
                        relation=relation,
                        relation_confidence=round(relation_confidence, 4),
                    )
                )

        # 若评分点合计小于题目满分，按比例映射到 max_score
        points_total = sum(p.score for p in points) or request.max_score
        if abs(points_total - request.max_score) > 1e-6 and points_total > 0:
            mapped = total / points_total * request.max_score
            mapped_provisional = provisional_total / points_total * request.max_score
        else:
            mapped = total
            mapped_provisional = provisional_total
        final_score = round(min(max(mapped, 0.0), request.max_score), precision)
        provisional_score = round(
            min(max(mapped_provisional, 0.0), request.max_score),
            precision,
        )

        if total_conflict_zero:
            final_score = 0.0
            provisional_score = 0.0
            applied_caps.append("critical_conflict:0.0")
            decision_reason = "critical_point_conflict_zero_total"
        elif total_conflict_cap_ratio < 1.0:
            cap = round(request.max_score * total_conflict_cap_ratio, precision)
            final_score = min(final_score, cap)
            provisional_score = min(provisional_score, cap)
            applied_caps.append(f"critical_conflict:{total_conflict_cap_ratio}")
            decision_reason = "critical_point_conflict_cap"

        confidence = weighted_conf / weight_sum if weight_sum else 0.0
        if hard_conflict:
            confidence = min(confidence, 0.4)
            force_review = True
            decision_reason = decision_reason or "hard_conflict"
        if required_unknown and relation_options.required_unknown_requires_review:
            force_review = True
            confidence = min(confidence, 0.55)
            warnings.append("必答或关键评分点关系不确定，拒绝自动定分")
            decision_reason = decision_reason or "required_point_unknown"
        if (
            supported_count == 0
            and unknown_count > 0
            and relation_options.reject_when_no_supported
            and any(not point.synthetic for point in points)
        ):
            final_score = 0.0
            force_review = True
            confidence = min(confidence, 0.55)
            warnings.append("没有评分点被可靠支持，存在不确定关系，拒绝自动定分")
            decision_reason = decision_reason or "no_supported_points_uncertain"
        elif supported_count == 0 and contradicted_count == len(points):
            final_score = 0.0
            force_review = True
            decision_reason = decision_reason or "all_points_contradicted"
        if decision_reason is None:
            if final_score <= 0.0:
                decision_reason = "no_supported_points"
            else:
                decision_reason = "supported_points"

        return IntermediateScoreResult(
            scorer=self.name,
            scoring_mode=ScoringMode.TEXT,
            score=final_score,
            provisional_score=provisional_score,
            max_score=request.max_score,
            confidence=round(float(max(0.0, min(1.0, confidence))), 4),
            matched_evidence=matched,
            missed_evidence=missed,
            warnings=warnings,
            force_manual_review=force_review,
            metadata={
                "model": backend_name,
                "parser": None,
                "match_threshold": support_threshold,
                "support_threshold": support_threshold,
                "conflict_threshold": conflict_threshold,
                "point_count": len(points),
                "relation_counts": {
                    "supported": supported_count,
                    "contradicted": contradicted_count,
                    "unknown": unknown_count,
                },
                "decision": (
                    "manual_review"
                    if force_review
                    else "auto_zero"
                    if final_score <= 0.0
                    else "auto_score"
                ),
                "decision_reason": decision_reason,
                "applied_caps": applied_caps,
                "bounded_corrections": {
                    "gated_points": gated_points,
                    "floored_points": floored_points,
                },
                "rubric_validation": rubric_diagnostics,
                "reference_cache_hit": reference_cache_hit,
                "evidence_batch_mode": (
                    "query_documents"
                    if isinstance(scorer, DocumentBatchScorer)
                    else "pair_matrix"
                ),
                "calibrator": getattr(calibrator, "name", type(calibrator).__name__),
                "point_diagnostics": point_diagnostics,
            },
        )

    def __call__(self, request: ScoringRequest) -> IntermediateScoreResult:
        return self.score(request)

    @staticmethod
    def _snippet(student: str, point_text: str, max_len: int = 80) -> str | None:
        if not student:
            return None
        # 取与评分点 token 重叠最多的短句
        sentences = re.split(r"[。！？!?\n；;]+", student)
        best = student
        best_score = -1.0
        pt = set(tokenize(point_text))
        for sent in sentences:
            s = sent.strip()
            if not s:
                continue
            st = set(tokenize(s))
            overlap = len(pt & st)
            if overlap > best_score:
                best_score = overlap
                best = s
        if len(best) > max_len:
            return best[: max_len - 1] + "…"
        return best


__all__ = [
    "RuleInterceptor",
    "ScoreCalibrator",
    "ScoringPointResolver",
    "TextRerankerScorer",
]
