"""Serve a fixed verification protocol on a dedicated, credential-free host.

Run behind a TLS reverse proxy. This service owns access to the sandbox host's
Docker daemon; business workers never receive that access.
"""

from __future__ import annotations

import argparse
import hmac
import hashlib
import json
import logging
import os
import re
import socket
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

from subjective_scoring.engines.code_execution import DockerCodeRunner
from subjective_scoring.engines.sql_execution import DockerSQLiteDatasetRunner
from subjective_scoring.sandbox_transport import MAX_REQUEST_BYTES, validate_report, validate_request


def build_fingerprint(release: str, images: dict[str, str]) -> str:
    if not release.strip() or len(release) > 100:
        raise ValueError("release build identifier is required")
    manifest = json.dumps(images, sort_keys=True, separators=(",", ":")).encode()
    return release + ":" + hashlib.sha256(manifest).hexdigest()[:16]


class _ParserDiagnosticFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        # SQLGlot's unsupported-command warning embeds the full submitted SQL.
        record.msg = "SQL parser diagnostic (input omitted)"
        record.args = ()
        record.exc_info = None
        record.exc_text = None
        return True


_parser_diagnostic_filter = _ParserDiagnosticFilter()


class SandboxServer(HTTPServer):
    # Serial execution bounds concurrent containers and request memory. Scale by isolated hosts.
    request_queue_size = 8

    def __init__(self, address: tuple[str, int], *, token: str, runner_build: str,
                 code_runner: Any | None = None, sql_runner: Any | None = None) -> None:
        if not isinstance(token, str) or len(token) < 32 or "\r" in token or "\n" in token:
            raise ValueError("a sandbox token of at least 32 characters is required")
        if not runner_build.strip() or len(runner_build) > 128:
            raise ValueError("runner build is required")
        self.token = token
        self.runner_build = runner_build
        self.code_runner = code_runner or DockerCodeRunner()
        self.sql_runner = sql_runner or DockerSQLiteDatasetRunner()
        logging.getLogger("sqlglot").addFilter(_parser_diagnostic_filter)
        super().__init__(address, SandboxHandler)

    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(5)
        return connection, address


class SandboxHandler(BaseHTTPRequestHandler):
    server: SandboxServer
    server_version = "SubjectiveSandbox/1"
    sys_version = ""

    def log_message(self, _format: str, *args: Any) -> None:
        # Requests contain student answers and hidden tests; no request/response logging.
        return

    def _authorized(self) -> bool:
        provided = self.headers.get("Authorization", "")
        expected = "Bearer " + self.server.token
        if not hmac.compare_digest(provided.encode(), expected.encode()):
            self._send(401, {"error": "unauthorized"})
            return False
        return True

    def _send(self, status: int, body: dict[str, Any]) -> None:
        raw = json.dumps(body, ensure_ascii=False, allow_nan=False).encode()
        self.close_connection = True
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        if not self._authorized():
            return
        if self.path != "/health":
            self._send(404, {"error": "not_found"})
            return
        # Liveness only. The separately documented smoke suite verifies images/isolation.
        self._send(200, {"schema_version": 1, "status": "ok", "runner_build": self.server.runner_build})

    def do_POST(self) -> None:
        if not self._authorized():
            return
        if self.path != "/v1/execute":
            self._send(404, {"error": "not_found"})
            return
        if self.headers.get("Transfer-Encoding") or self.headers.get("Content-Type") != "application/json":
            self._send(400, {"error": "invalid_request"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= MAX_REQUEST_BYTES:
                self._send(413, {"error": "request_size_limit"})
                return
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError("incomplete request")
            payload = validate_request(json.loads(raw))
        except (ValueError, TypeError, UnicodeError, socket.timeout, KeyError):
            self._send(400, {"error": "invalid_request"})
            return
        except Exception:
            self._send(400, {"error": "invalid_request"})
            return
        try:
            if payload["operation"] == "code":
                report = self.server.code_runner.run(payload["source"], payload["language"], payload["test_cases"])
            else:
                report = self.server.sql_runner.run(
                    payload["reference_sql"], payload["student_sql"], payload["dialect"], payload["datasets"],
                    **({"sql_execution": payload["execution"]} if "execution" in payload else {})
                ).to_dict()
            sanitized = validate_report(payload, report)
            self._send(200, {"schema_version": 1, "runner_build": self.server.runner_build, "report": sanitized})
        except Exception:
            self._send(503, {"error": "verification_unavailable"})


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bind", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8099)
    args = parser.parse_args()
    # Reject accidental reuse of the business worker's environment file.
    business_secrets = (
        "DATABASE_URL", "EXAM_DATABASE_URL", "EXAM_MIGRATOR_DATABASE_URL",
        "EXAM_ADMIN_PASSWORD", "LLM_API_KEY", "RERANK_API_KEY",
        "PG_PASSWORD", "PG_APP_PASSWORD", "PG_MIGRATOR_PASSWORD", "OPENAI_API_KEY",
    )
    if any(os.environ.get(key) for key in business_secrets):
        parser.error("sandbox must not inherit business credentials")
    images = {language: os.environ.get(key, "") for language, key in (
        ("python", "SANDBOX_PYTHON_IMAGE"), ("javascript", "SANDBOX_JAVASCRIPT_IMAGE"),
        ("java", "SANDBOX_JAVA_IMAGE"),
    )}
    if any(not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]*@sha256:[0-9a-f]{64}", image)
           for image in images.values()):
        parser.error("all sandbox images must be pinned to SHA-256 digests")
    try:
        server = SandboxServer((args.bind, args.port),
                               token=os.environ.get("SANDBOX_AUTH_TOKEN", ""),
                               runner_build=build_fingerprint(os.environ.get("SANDBOX_RUNNER_BUILD", ""), images),
                               code_runner=DockerCodeRunner(images=images),
                               sql_runner=DockerSQLiteDatasetRunner(image=images["python"]))
    except ValueError as exc:
        parser.error(str(exc))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
