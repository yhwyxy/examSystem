"""Bounded query and opt-in mutation validation against isolated SQLite datasets."""

from __future__ import annotations

import json
import math
import re
import sqlite3
import time
from dataclasses import dataclass
from typing import Any
from subjective_scoring.sql_policy import normalize_sql_execution

try:
    import sqlglot
    from sqlglot import exp
except ImportError:  # pragma: no cover
    sqlglot = None  # type: ignore[assignment]
    exp = None  # type: ignore[assignment]


_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,62}$")
_COLUMN_TYPES = {"INTEGER", "REAL", "TEXT", "BLOB", "NUMERIC"}
_MAX_FIXTURE_BYTES = 2 * 1024 * 1024
_MAX_RESULT_COLUMNS = 100
_MAX_RESULT_CELLS = 100_000
_MAX_RESULT_BYTES = 2 * 1024 * 1024
_MAX_SQLITE_VALUE_BYTES = 1024 * 1024
_MAX_SANDBOX_INPUT_BYTES = 3 * 1024 * 1024
_VOLATILE_FUNCTIONS = {
    "current_date", "current_time", "current_timestamp", "random", "randomblob",
}
_ALLOWED_ACTIONS = {
    sqlite3.SQLITE_SELECT,
    sqlite3.SQLITE_READ,
    sqlite3.SQLITE_FUNCTION,
}
if hasattr(sqlite3, "SQLITE_RECURSIVE"):
    _ALLOWED_ACTIONS.add(sqlite3.SQLITE_RECURSIVE)


@dataclass(frozen=True)
class SQLExecutionReport:
    status: str
    dialect: str | None
    passed: int
    total: int
    datasets: list[dict[str, Any]]
    reason: str | None = None
    runner_build: str | None = None

    def to_dict(self) -> dict[str, Any]:
        report = {
            "status": self.status,
            "dialect": self.dialect,
            "passed": self.passed,
            "total": self.total,
            "datasets": self.datasets,
            "reason": self.reason,
        }
        if self.runner_build is not None:
            report["runner_build"] = self.runner_build
        return report


class SQLiteDatasetRunner:
    """In-process SQLite harness for deterministic unit tests and local diagnostics."""

    def __init__(
        self,
        *,
        query_timeout_seconds: float = 0.25,
        max_vm_steps: int = 200_000,
        max_result_rows: int = 5000,
        max_result_cells: int = _MAX_RESULT_CELLS,
        max_result_bytes: int = _MAX_RESULT_BYTES,
    ) -> None:
        self.query_timeout_seconds = query_timeout_seconds
        self.max_vm_steps = max_vm_steps
        self.max_result_rows = max_result_rows
        self.max_result_cells = max_result_cells
        self.max_result_bytes = max_result_bytes

    def run(
        self,
        reference_sql: str,
        student_sql: str,
        dialect: str | None,
        datasets: list[dict[str, Any]],
        sql_execution: dict[str, Any] | None = None,
    ) -> SQLExecutionReport:
        normalized_dialect = (dialect or "").strip().lower()
        if normalized_dialect != "sqlite":
            return self._unable(normalized_dialect or None, "unsupported_or_missing_dialect")
        if sqlglot is None:
            return self._unable(normalized_dialect, "sql_parser_unavailable")
        if not reference_sql.strip() or not student_sql.strip():
            return self._unable(normalized_dialect, "reference_or_student_sql_empty")
        if not isinstance(datasets, list) or len(datasets) < 2 or len(datasets) > 20:
            return self._unable(normalized_dialect, "at_least_two_datasets_required")
        if len(reference_sql) > 10_000 or len(student_sql) > 10_000:
            return self._unable(normalized_dialect, "query_size_limit")

        try:
            policy = normalize_sql_execution({} if sql_execution is None else sql_execution)
            reference_ast = _parse_execution_sql(reference_sql, policy)
            _parse_execution_sql(student_sql, policy)
            prepared = [_validate_dataset(item) for item in datasets]
            if sum(dataset["fixture_bytes"] for dataset in prepared) > _MAX_FIXTURE_BYTES:
                raise InvalidFixture
            names = [dataset["name"].casefold() for dataset in prepared]
            if len(set(names)) != len(names):
                raise InvalidFixture
            _validate_mutation_fixtures(prepared, policy)
        except UnsupportedSQL:
            return self._unable(normalized_dialect, "unsupported_statement")
        except InvalidFixture:
            return self._unable(normalized_dialect, "invalid_dataset")
        except Exception:
            return self._unable(normalized_dialect, "reference_or_student_sql_invalid")

        if policy["mode"] == "mutation":
            return self._run_mutations(reference_sql, student_sql, prepared, policy)

        order_sensitive = bool(reference_ast.args.get("order"))
        results: list[dict[str, Any]] = []
        passed = 0
        for index, dataset in enumerate(prepared):
            try:
                conn = _create_fixture_database(dataset)
            except Exception:
                return self._unable(normalized_dialect, "fixture_setup_failed")
            try:
                expected = self._execute(conn, reference_sql)
            except Exception:
                conn.close()
                return self._unable(normalized_dialect, "reference_execution_failed")
            actual: list[tuple[Any, ...]] | None = None
            try:
                actual = self._execute(conn, student_sql)
                matched = _same_rows(expected, actual, order_sensitive)
                reason = "result_match" if matched else "result_mismatch"
            except UnsupportedSQL:
                conn.close()
                return self._unable(normalized_dialect, "unsupported_student_statement")
            except QueryTimeLimit:
                matched, reason = False, "student_query_time_limit"
            except ResultLimit:
                matched, reason = False, "student_result_limit"
            except sqlite3.Error as exc:
                if "not authorized" in str(exc).lower():
                    conn.close()
                    return self._unable(normalized_dialect, "unsafe_student_statement")
                matched, reason = False, "student_query_error"
            except Exception:
                conn.close()
                return self._unable(normalized_dialect, "student_execution_unavailable")
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
            if matched:
                passed += 1
            visibility = dataset["visibility"]
            results.append({
                "name": dataset["name"] if visibility == "public" else f"hidden_case_{index + 1}",
                "visibility": visibility,
                "passed": matched,
                "expected_rows": len(expected),
                "actual_rows": len(actual) if actual is not None else None,
                "reason": reason,
            })
        return SQLExecutionReport(
            status="verified",
            dialect=normalized_dialect,
            passed=passed,
            total=len(prepared),
            datasets=results,
        )

    def _run_mutations(self, reference: str, student: str, datasets: list[dict[str, Any]],
                       policy: dict[str, Any]) -> SQLExecutionReport:
        results = []
        for index, dataset in enumerate(datasets):
            reference_conn = student_conn = None
            try:
                reference_conn = _create_fixture_database(dataset)
                student_conn = _create_fixture_database(dataset)
                self._execute(reference_conn, reference, policy["mutation_tables"])
                expected = self._snapshot(reference_conn, dataset)
            except Exception:
                if reference_conn is not None:
                    reference_conn.close()
                if student_conn is not None:
                    student_conn.close()
                return self._unable("sqlite", "reference_execution_failed")
            actual = None
            try:
                self._execute(student_conn, student, policy["mutation_tables"])
                actual = self._snapshot(student_conn, dataset)
                matched = _same_rows(expected, actual, False)
                reason = "state_match" if matched else "state_mismatch"
            except QueryTimeLimit:
                matched, reason = False, "student_query_time_limit"
            except ResultLimit:
                matched, reason = False, "student_result_limit"
            except sqlite3.Error as exc:
                if "not authorized" in str(exc).lower():
                    return self._unable("sqlite", "unsafe_student_statement")
                matched, reason = False, "student_query_error"
            except Exception:
                return self._unable("sqlite", "student_execution_unavailable")
            finally:
                reference_conn.close()
                student_conn.close()
            visibility = dataset["visibility"]
            results.append({"name": dataset["name"] if visibility == "public" else f"hidden_case_{index + 1}",
                            "visibility": visibility, "passed": matched, "reason": reason,
                            "expected_rows": len(expected), "actual_rows": len(actual) if actual is not None else None})
        return SQLExecutionReport("verified", "sqlite", sum(item["passed"] for item in results), len(results), results)

    def _snapshot(self, conn: sqlite3.Connection, dataset: dict[str, Any]) -> list[tuple[Any, ...]]:
        rows = []
        for table in dataset["tables"]:
            current = self._execute(conn, f'SELECT * FROM "{table["name"]}"')
            rows.extend((table["name"].lower(), *row) for row in current)
        if (len(rows) > self.max_result_rows or sum(len(row) for row in rows) > self.max_result_cells
                or len(json.dumps(rows, ensure_ascii=False).encode()) > self.max_result_bytes):
            raise ResultLimit
        return rows

    def _execute(self, conn: sqlite3.Connection, sql: str,
                 mutation_tables: list[str] | None = None) -> list[tuple[Any, ...]]:
        if mutation_tables:
            _parse_execution_sql(sql, {"mode": "mutation", "mutation_tables": mutation_tables})
        else:
            _parse_read_query(sql)
        if hasattr(conn, "setlimit") and hasattr(sqlite3, "SQLITE_LIMIT_LENGTH"):
            conn.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, _MAX_SQLITE_VALUE_BYTES)
        steps = 0
        deadline = time.monotonic() + self.query_timeout_seconds

        def progress() -> int:
            nonlocal steps
            steps += 1000
            return int(steps > self.max_vm_steps or time.monotonic() > deadline)

        def authorize(action: int, arg1: str | None, arg2: str | None, _db: str | None, _trigger: str | None) -> int:
            if action in {sqlite3.SQLITE_INSERT, sqlite3.SQLITE_UPDATE, sqlite3.SQLITE_DELETE}:
                return sqlite3.SQLITE_OK if (arg1 or "").lower() in (mutation_tables or []) else sqlite3.SQLITE_DENY
            if action not in _ALLOWED_ACTIONS:
                return sqlite3.SQLITE_DENY
            if action == sqlite3.SQLITE_FUNCTION and (arg2 or arg1 or "").lower() in _VOLATILE_FUNCTIONS:
                return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK

        conn.set_authorizer(authorize)
        conn.set_progress_handler(progress, 1000)
        try:
            before = conn.total_changes
            cursor = conn.execute(sql)
            if conn.total_changes - before > self.max_result_rows:
                raise ResultLimit
            rows: list[tuple[Any, ...]] = []
            result_cells = 0
            result_bytes = 0
            while batch := cursor.fetchmany(128):
                if len(rows) + len(batch) > self.max_result_rows:
                    raise ResultLimit
                for row in batch:
                    if len(row) > _MAX_RESULT_COLUMNS:
                        raise ResultLimit
                    result_cells += len(row)
                    if result_cells > self.max_result_cells:
                        raise ResultLimit
                    normalized = tuple(_normalize_cell(cell) for cell in row)
                    result_bytes += len(json.dumps(
                        normalized, ensure_ascii=False, separators=(",", ":"),
                    ).encode("utf-8"))
                    if result_bytes > self.max_result_bytes:
                        raise ResultLimit
                    rows.append(normalized)
            if conn.total_changes - before > self.max_result_rows:
                raise ResultLimit
            return rows
        except sqlite3.OperationalError as exc:
            if "interrupted" in str(exc).lower():
                raise QueryTimeLimit from exc
            raise
        finally:
            conn.set_progress_handler(None, 0)
            conn.set_authorizer(None)

    @staticmethod
    def _unable(dialect: str | None, reason: str) -> SQLExecutionReport:
        return SQLExecutionReport("unable_to_verify", dialect, 0, 0, [], reason)


_SQL_SANDBOX_SCRIPT = r'''import json, math, sqlite3, sys, time
MAX_ROWS, MAX_COLUMNS, MAX_CELLS = 5000, 100, 100000
MAX_BYTES, MAX_VALUE_BYTES = 2 * 1024 * 1024, 1024 * 1024
ALLOWED = {sqlite3.SQLITE_SELECT, sqlite3.SQLITE_READ, sqlite3.SQLITE_FUNCTION}
if hasattr(sqlite3, "SQLITE_RECURSIVE"):
    ALLOWED.add(sqlite3.SQLITE_RECURSIVE)
VOLATILE = {"current_date", "current_time", "current_timestamp", "random", "randomblob"}
class Limit(Exception): pass
class Timeout(Exception): pass
def normalize(value):
    if isinstance(value, float):
        if not math.isfinite(value): return None
        if value.is_integer(): return int(value)
        return round(value, 12)
    if isinstance(value, bytes): return {"blob_hex": value.hex()}
    return value
def execute(conn, sql, mutation_tables=()):
    steps, deadline = [0], time.monotonic() + 0.25
    def progress():
        steps[0] += 1000
        return int(steps[0] > 200000 or time.monotonic() > deadline)
    def authorize(action, arg1, arg2, _db, _trigger):
        if action in {sqlite3.SQLITE_INSERT, sqlite3.SQLITE_UPDATE, sqlite3.SQLITE_DELETE}:
            return sqlite3.SQLITE_OK if (arg1 or "").lower() in mutation_tables else sqlite3.SQLITE_DENY
        if action not in ALLOWED: return sqlite3.SQLITE_DENY
        if action == sqlite3.SQLITE_FUNCTION and (arg2 or arg1 or "").lower() in VOLATILE:
            return sqlite3.SQLITE_DENY
        return sqlite3.SQLITE_OK
    conn.set_authorizer(authorize)
    conn.set_progress_handler(progress, 1000)
    try:
        before = conn.total_changes
        cursor = conn.execute(sql)
        rows, cells, size = [], 0, 0
        while True:
            batch = cursor.fetchmany(128)
            if not batch: break
            if len(rows) + len(batch) > MAX_ROWS: raise Limit()
            for row in batch:
                if len(row) > MAX_COLUMNS: raise Limit()
                cells += len(row)
                if cells > MAX_CELLS: raise Limit()
                current = tuple(normalize(cell) for cell in row)
                size += len(json.dumps(current, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
                if size > MAX_BYTES: raise Limit()
                rows.append(current)
        if conn.total_changes - before > MAX_ROWS: raise Limit()
        return rows
    except sqlite3.OperationalError as exc:
        if "interrupted" in str(exc).lower(): raise Timeout() from exc
        raise
    finally:
        conn.set_progress_handler(None, 0)
        conn.set_authorizer(None)
def make_database(dataset):
    conn = sqlite3.connect(":memory:", isolation_level=None)
    conn.enable_load_extension(False)
    conn.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, MAX_VALUE_BYTES)
    conn.execute("PRAGMA trusted_schema=OFF")
    for table in dataset["tables"]:
        columns = ", ".join("\"%s\" %s" % (name, kind) for name, kind in table["columns"])
        conn.execute("CREATE TABLE \"%s\" (%s)" % (table["name"], columns))
        marks = ", ".join("?" for _ in table["columns"])
        conn.executemany("INSERT INTO \"%s\" VALUES (%s)" % (table["name"], marks), table["rows"])
    return conn
def evaluate(conn, sql, dataset, policy):
    if policy["mode"] == "query": return execute(conn, sql)
    execute(conn, sql, policy["mutation_tables"])
    rows = []
    for table in dataset["tables"]:
        rows.extend((table["name"].lower(), *row) for row in execute(conn, 'SELECT * FROM "%s"' % table["name"]))
    if len(rows) > MAX_ROWS or sum(len(row) for row in rows) > MAX_CELLS: raise Limit()
    if len(json.dumps(rows, ensure_ascii=False).encode("utf-8")) > MAX_BYTES: raise Limit()
    return rows
def main():
    raw = sys.stdin.buffer.read(MAX_BYTES + 1024 * 1024 + 1)
    if len(raw) > MAX_BYTES + 1024 * 1024: raise ValueError("request too large")
    payload = json.loads(raw)
    policy = payload.get("execution", {"mode":"query", "mutation_tables":[]})
    mutation = policy["mode"] == "mutation"
    results = []
    for dataset in payload["datasets"]:
        conn = make_database(dataset)
        student_conn = make_database(dataset)
        try:
            try:
                expected = evaluate(conn, payload["reference_sql"], dataset, policy)
            except Exception:
                print(json.dumps({"status":"unable_to_verify","reason":"reference_execution_failed"}))
                return
            try:
                actual = evaluate(student_conn, payload["student_sql"], dataset, policy)
                if payload["order_sensitive"] and not mutation:
                    matched = expected == actual
                else:
                    key = lambda row: json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
                    matched = sorted(expected, key=key) == sorted(actual, key=key)
                reason = ("state_match" if matched else "state_mismatch") if mutation else ("result_match" if matched else "result_mismatch")
                actual_count = len(actual)
            except Timeout:
                matched, reason, actual_count = False, "student_query_time_limit", None
            except Limit:
                matched, reason, actual_count = False, "student_result_limit", None
            except sqlite3.Error as exc:
                if "not authorized" in str(exc).lower():
                    print(json.dumps({"status":"unable_to_verify","reason":"unsafe_student_statement"}))
                    return
                matched, reason, actual_count = False, "student_query_error", None
            results.append({"passed": matched, "expected_rows": len(expected), "actual_rows": actual_count, "reason": reason})
        finally:
            conn.close()
            student_conn.close()
    print(json.dumps({"status":"verified","results":results}, separators=(",", ":")))
main()
'''


class DockerSQLiteDatasetRunner:
    """Runs validated SQLite fixtures in a network-disabled, credential-free container."""

    def __init__(
        self,
        *,
        command_runner: Any | None = None,
        runtime: str = "docker",
        total_timeout_seconds: float = 15.0,
        image: str = "python:3.12-slim",
    ) -> None:
        from subjective_scoring.engines.code_execution import BoundedSubprocessRunner

        self.command_runner = command_runner or BoundedSubprocessRunner()
        self.runtime = runtime
        self.total_timeout_seconds = total_timeout_seconds
        self.image = image

    def run(
        self,
        reference_sql: str,
        student_sql: str,
        dialect: str | None,
        datasets: list[dict[str, Any]],
        sql_execution: dict[str, Any] | None = None,
    ) -> SQLExecutionReport:
        normalized_dialect = (dialect or "").strip().lower()
        if normalized_dialect != "sqlite":
            return SQLiteDatasetRunner._unable(normalized_dialect or None, "unsupported_or_missing_dialect")
        if sqlglot is None:
            return SQLiteDatasetRunner._unable(normalized_dialect, "sql_parser_unavailable")
        if not reference_sql.strip() or not student_sql.strip():
            return SQLiteDatasetRunner._unable(normalized_dialect, "reference_or_student_sql_empty")
        if not isinstance(datasets, list) or len(datasets) < 2 or len(datasets) > 20:
            return SQLiteDatasetRunner._unable(normalized_dialect, "at_least_two_datasets_required")
        if len(reference_sql) > 10_000 or len(student_sql) > 10_000:
            return SQLiteDatasetRunner._unable(normalized_dialect, "query_size_limit")
        try:
            policy = normalize_sql_execution({} if sql_execution is None else sql_execution)
            reference_ast = _parse_execution_sql(reference_sql, policy)
            _parse_execution_sql(student_sql, policy)
            prepared = [_validate_dataset(item) for item in datasets]
            if sum(dataset["fixture_bytes"] for dataset in prepared) > _MAX_FIXTURE_BYTES:
                raise InvalidFixture
            names = [dataset["name"].casefold() for dataset in prepared]
            if len(set(names)) != len(names):
                raise InvalidFixture
            _validate_mutation_fixtures(prepared, policy)
        except UnsupportedSQL:
            return SQLiteDatasetRunner._unable(normalized_dialect, "unsupported_statement")
        except InvalidFixture:
            return SQLiteDatasetRunner._unable(normalized_dialect, "invalid_dataset")
        except Exception:
            return SQLiteDatasetRunner._unable(normalized_dialect, "reference_or_student_sql_invalid")

        payload = {
            "reference_sql": reference_sql,
            "student_sql": student_sql,
            "order_sensitive": bool(reference_ast.args.get("order")),
            "datasets": prepared,
            "execution": policy,
        }
        try:
            input_data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            if len(input_data) > _MAX_SANDBOX_INPUT_BYTES:
                return SQLiteDatasetRunner._unable(normalized_dialect, "invalid_dataset")
            inspected = self.command_runner.run(
                [self.runtime, "image", "inspect", "--format={{.Id}}", self.image],
                input_data=None,
                timeout=4,
                output_limit=4096,
            )
        except (OSError, ValueError, TypeError):
            return SQLiteDatasetRunner._unable(normalized_dialect, "container_runtime_unavailable")
        if inspected.returncode != 0 or inspected.timed_out:
            error = inspected.stderr.decode("utf-8", errors="replace").lower()
            reason = "container_runtime_unavailable" if any(
                part in error for part in ("cannot connect", "daemon", "socket", "permission denied")
            ) else "container_image_unavailable"
            return SQLiteDatasetRunner._unable(normalized_dialect, reason)

        import tempfile
        import uuid
        try:
            with tempfile.TemporaryDirectory(prefix="subjective-sql-") as directory:
                name = f"sql-scoring-{uuid.uuid4().hex[:20]}"
                command = [
                    self.runtime, "run", "--rm", "--pull=never", "--init", "-i",
                    f"--name={name}", f"--cidfile={directory}/container.id",
                    "--label=subjective-scoring.sandbox=true",
                    "--network=none", "--read-only", "--cap-drop=ALL",
                    "--security-opt=no-new-privileges",
                    "--pids-limit=16", "--memory=128m", "--memory-swap=128m",
                    "--cpus=1", "--ulimit=cpu=12:12", "--ulimit=nofile=32:32",
                    "--user=65534:65534", "--tmpfs=/tmp:rw,nosuid,nodev,size=8m",
                    self.image, "python", "-I", "-S", "-c", _SQL_SANDBOX_SCRIPT,
                ]
                outcome = self.command_runner.run(
                    command,
                    input_data=input_data,
                    timeout=self.total_timeout_seconds,
                    output_limit=16 * 1024,
                    container_name=name,
                )
        except (OSError, ValueError, TypeError):
            return SQLiteDatasetRunner._unable(normalized_dialect, "container_runtime_unavailable")
        if outcome.timed_out:
            return SQLiteDatasetRunner._unable(normalized_dialect, "container_execution_timeout")
        if outcome.output_limited or not outcome.container_started or outcome.returncode != 0:
            return SQLiteDatasetRunner._unable(normalized_dialect, "container_execution_failed")
        try:
            response = json.loads(outcome.stdout)
            if response.get("status") != "verified":
                return SQLiteDatasetRunner._unable(
                    normalized_dialect, str(response.get("reason") or "container_execution_failed")
                )
            raw_results = response["results"]
            if not isinstance(raw_results, list) or len(raw_results) != len(prepared):
                raise ValueError("result count mismatch")
            results = []
            passed = 0
            for index, raw in enumerate(raw_results):
                if not isinstance(raw, dict) or not isinstance(raw.get("passed"), bool):
                    raise ValueError("invalid result")
                if raw["reason"] not in {"result_match", "result_mismatch", "state_match", "state_mismatch", "student_query_time_limit", "student_result_limit", "student_query_error"}:
                    raise ValueError("invalid result reason")
                if raw["passed"]:
                    passed += 1
                visibility = prepared[index]["visibility"]
                results.append({
                    "name": prepared[index]["name"] if visibility == "public" else f"hidden_case_{index + 1}",
                    "visibility": visibility,
                    "passed": raw["passed"],
                    "expected_rows": _nonnegative_int(raw.get("expected_rows")),
                    "actual_rows": _optional_nonnegative_int(raw.get("actual_rows")),
                    "reason": raw["reason"],
                })
        except (json.JSONDecodeError, KeyError, TypeError, ValueError):
            return SQLiteDatasetRunner._unable(normalized_dialect, "container_result_invalid")
        return SQLExecutionReport("verified", normalized_dialect, passed, len(results), results)


def _nonnegative_int(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError("invalid row count")
    return value


def _optional_nonnegative_int(value: Any) -> int | None:
    if value is None:
        return None
    return _nonnegative_int(value)


class UnsupportedSQL(Exception):
    pass


class InvalidFixture(Exception):
    pass


class QueryTimeLimit(Exception):
    pass


class ResultLimit(Exception):
    pass


def _parse_read_query(sql: str):
    assert sqlglot is not None and exp is not None
    try:
        statements = [item for item in sqlglot.parse(sql, read="sqlite") if item is not None]
    except Exception as exc:
        raise ValueError("invalid SQL") from exc
    if len(statements) != 1:
        raise UnsupportedSQL("only one SQL statement is supported")
    statement = statements[0]
    if statement.key not in {"select", "union", "intersect", "except"}:
        raise UnsupportedSQL("only read queries are supported")
    return statement


def _parse_execution_sql(sql: str, policy: dict[str, Any]):
    if policy["mode"] == "query":
        return _parse_read_query(sql)
    assert sqlglot is not None and exp is not None
    statements = [statement for statement in sqlglot.parse(sql, read="sqlite") if statement is not None]
    if len(statements) != 1 or statements[0].key not in {"insert", "update", "delete"}:
        raise UnsupportedSQL("configured mutations support one INSERT, UPDATE or DELETE")
    statement = statements[0]
    target = statement.this
    if isinstance(target, exp.Schema):
        target = target.this
    if not isinstance(target, exp.Table) or target.name.lower() not in policy["mutation_tables"]:
        raise UnsupportedSQL("mutation target is not allowed")
    if any(table.db or table.catalog for table in statement.find_all(exp.Table)):
        raise UnsupportedSQL("qualified databases are not supported")
    return statement


def _validate_mutation_fixtures(datasets: list[dict[str, Any]], policy: dict[str, Any]) -> None:
    for dataset in datasets:
        tables = {table["name"].lower() for table in dataset["tables"]}
        if not set(policy["mutation_tables"]).issubset(tables):
            raise InvalidFixture


def _validate_dataset(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise InvalidFixture
    name = raw.get("name")
    visibility = raw.get("visibility", "hidden")
    tables = raw.get("tables", [])
    if not isinstance(name, str) or not name.strip() or len(name) > 80:
        raise InvalidFixture
    if visibility not in {"public", "hidden"} or not isinstance(tables, list) or len(tables) > 50:
        raise InvalidFixture
    checked_tables = []
    seen_tables: set[str] = set()
    total_rows = 0
    total_cells = 0
    fixture_bytes = len(name.strip().encode("utf-8")) + 64
    for table in tables:
        if not isinstance(table, dict):
            raise InvalidFixture
        table_name = table.get("name")
        columns = table.get("columns")
        rows = table.get("rows", [])
        if not isinstance(table_name, str) or not _IDENTIFIER.fullmatch(table_name):
            raise InvalidFixture
        if table_name.lower() in seen_tables:
            raise InvalidFixture
        seen_tables.add(table_name.lower())
        fixture_bytes += len(table_name.encode("utf-8")) + 64
        if not isinstance(columns, list) or not columns or len(columns) > 50:
            raise InvalidFixture
        if not isinstance(rows, list) or len(rows) > 1000:
            raise InvalidFixture
        checked_columns = []
        seen_columns: set[str] = set()
        for column in columns:
            if not isinstance(column, dict):
                raise InvalidFixture
            column_name = column.get("name")
            column_type = str(column.get("type", "TEXT")).upper()
            if not isinstance(column_name, str) or not _IDENTIFIER.fullmatch(column_name):
                raise InvalidFixture
            if column_name.lower() in seen_columns or column_type not in _COLUMN_TYPES:
                raise InvalidFixture
            seen_columns.add(column_name.lower())
            checked_columns.append((column_name, column_type))
            fixture_bytes += len(column_name.encode("utf-8")) + len(column_type) + 16
        checked_rows = []
        for row in rows:
            if not isinstance(row, list) or len(row) != len(checked_columns):
                raise InvalidFixture
            if any(not _valid_cell(cell) for cell in row):
                raise InvalidFixture
            fixture_bytes += 16
            for cell in row:
                fixture_bytes += len(cell.encode("utf-8")) + 4 if isinstance(cell, str) else 16
            checked_rows.append(tuple(row))
        total_rows += len(checked_rows)
        total_cells += len(checked_rows) * len(checked_columns)
        if total_rows > 2000 or total_cells > 20_000:
            raise InvalidFixture
        checked_tables.append({"name": table_name, "columns": checked_columns, "rows": checked_rows})
    return {
        "name": name.strip(), "visibility": visibility,
        "tables": checked_tables, "fixture_bytes": fixture_bytes,
    }


def _valid_cell(value: Any) -> bool:
    if value is None or isinstance(value, (str, int, bool)):
        return not isinstance(value, str) or len(value) <= 4096
    if isinstance(value, float):
        return math.isfinite(value)
    return False


def _create_fixture_database(dataset: dict[str, Any]) -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:", isolation_level=None)
    conn.enable_load_extension(False)
    conn.execute("PRAGMA trusted_schema=OFF")
    for table in dataset["tables"]:
        columns = ", ".join(f'"{name}" {column_type}' for name, column_type in table["columns"])
        conn.execute(f'CREATE TABLE "{table["name"]}" ({columns})')
        placeholders = ", ".join("?" for _ in table["columns"])
        conn.executemany(
            f'INSERT INTO "{table["name"]}" VALUES ({placeholders})',
            table["rows"],
        )
    return conn


def _normalize_cell(value: Any) -> Any:
    if isinstance(value, float):
        if not math.isfinite(value):
            return None
        if value.is_integer():
            return int(value)
        return round(value, 12)
    if isinstance(value, bytes):
        return {"blob_hex": value.hex()}
    return value


def _same_rows(expected: list[tuple[Any, ...]], actual: list[tuple[Any, ...]], order_sensitive: bool) -> bool:
    if order_sensitive:
        return expected == actual
    key = lambda row: json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return sorted(expected, key=key) == sorted(actual, key=key)


__all__ = ["DockerSQLiteDatasetRunner", "SQLiteDatasetRunner", "SQLExecutionReport"]
