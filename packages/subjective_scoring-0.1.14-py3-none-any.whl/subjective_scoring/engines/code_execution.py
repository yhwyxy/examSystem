"""Resource-limited code execution through a network-disabled Docker container."""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol


_IMAGES = {
    "python": ("python:3.12-slim", ["python", "-I", "-S", "/submission/main.py"]),
    "javascript": ("node:22-alpine", ["node", "--max-old-space-size=128", "/submission/main.js"]),
    "java": (
        "eclipse-temurin:21-jdk",
        ["sh", "-c", "javac -encoding UTF-8 -d /tmp /submission/Main.java && java -Xms16m -Xmx128m -XX:MaxMetaspaceSize=64m -cp /tmp Main"],
    ),
}
_MAX_SOURCE_BYTES = 64 * 1024
_MAX_CASES = 12
_MAX_IO_BYTES = 16 * 1024
_MAX_OUTPUT_BYTES = 32 * 1024


@dataclass(frozen=True)
class ProcessResult:
    returncode: int
    stdout: bytes
    stderr: bytes
    timed_out: bool = False
    output_limited: bool = False
    container_started: bool = False


class ContainerCommandRunner(Protocol):
    def run(
        self,
        command: list[str],
        *,
        input_data: bytes | None,
        timeout: float,
        output_limit: int,
        container_name: str | None = None,
    ) -> ProcessResult: ...


class BoundedSubprocessRunner:
    """Runs the Docker CLI with bounded output capture and kills timed-out containers."""

    def run(
        self,
        command: list[str],
        *,
        input_data: bytes | None,
        timeout: float,
        output_limit: int,
        container_name: str | None = None,
    ) -> ProcessResult:
        env = _docker_environment()
        cidfile = next((arg.split("=", 1)[1] for arg in command if arg.startswith("--cidfile=")), None)
        process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
        )
        stdout = bytearray()
        stderr = bytearray()
        output_limited = threading.Event()

        def drain(pipe, target: bytearray) -> None:
            while True:
                chunk = pipe.read(8192)
                if not chunk:
                    return
                remaining = output_limit - len(target)
                if len(chunk) > remaining:
                    if remaining > 0:
                        target.extend(chunk[:remaining])
                    output_limited.set()
                    return
                target.extend(chunk)

        def feed_stdin() -> None:
            if process.stdin is None:
                return
            try:
                if input_data:
                    process.stdin.write(input_data)
                    process.stdin.flush()
            except (BrokenPipeError, OSError):
                pass
            finally:
                try:
                    process.stdin.close()
                except OSError:
                    pass

        readers = [
            threading.Thread(target=drain, args=(process.stdout, stdout), daemon=True),
            threading.Thread(target=drain, args=(process.stderr, stderr), daemon=True),
            threading.Thread(target=feed_stdin, daemon=True),
        ]
        for thread in readers:
            thread.start()
        timed_out = False
        deadline = time.monotonic() + timeout
        while process.poll() is None:
            if output_limited.is_set():
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                timed_out = True
                break
            try:
                process.wait(timeout=min(0.05, remaining))
            except subprocess.TimeoutExpired:
                continue
        if timed_out or output_limited.is_set():
            if container_name:
                self._kill_container(command[0], container_name, env)
            if process.poll() is None:
                process.terminate()
            try:
                process.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=0.5)
        for thread in readers:
            thread.join(timeout=0.5)
        if process.stdout:
            process.stdout.close()
        if process.stderr:
            process.stderr.close()
        container_started = bool(cidfile and Path(cidfile).is_file())
        return ProcessResult(
            returncode=process.returncode if process.returncode is not None else -1,
            stdout=bytes(stdout),
            stderr=bytes(stderr),
            timed_out=timed_out,
            output_limited=output_limited.is_set(),
            container_started=container_started,
        )

    @staticmethod
    def _kill_container(runtime: str, name: str, env: dict[str, str]) -> None:
        for operation in ("kill", "rm"):
            command = [runtime, operation]
            if operation == "rm":
                command.append("-f")
            command.append(name)
            try:
                subprocess.run(
                    command,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    env=env,
                    timeout=2,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                pass


class DockerCodeRunner:
    """Runs stdin/stdout tests without mounting application credentials or network."""

    def __init__(
        self,
        *,
        command_runner: ContainerCommandRunner | None = None,
        runtime: str = "docker",
        case_timeout_seconds: float = 8.0,
        total_timeout_seconds: float = 45.0,
        images: dict[str, str] | None = None,
    ) -> None:
        self.command_runner = command_runner or BoundedSubprocessRunner()
        self.runtime = runtime
        self.case_timeout_seconds = case_timeout_seconds
        self.total_timeout_seconds = total_timeout_seconds
        self.images = {language: image for language, (image, _) in _IMAGES.items()}
        if images is not None:
            if set(images) != set(_IMAGES) or any(not isinstance(image, str) or not image for image in images.values()):
                raise ValueError("all supported language images must be configured")
            self.images = dict(images)

    def run(self, source: str, language: str | None, test_cases: list[dict[str, Any]]) -> dict[str, Any]:
        normalized_language = (language or "").strip().lower()
        if normalized_language not in _IMAGES:
            return self._unable(normalized_language or None, "unsupported_or_missing_language")
        if not isinstance(source, str) or not source.strip() or len(source.encode("utf-8")) > _MAX_SOURCE_BYTES:
            return self._unable(normalized_language, "source_size_or_content_invalid")
        try:
            cases = _validate_cases(test_cases)
        except ValueError:
            return self._unable(normalized_language, "invalid_test_cases")
        _, entrypoint = _IMAGES[normalized_language]
        image = self.images[normalized_language]
        try:
            inspected = self.command_runner.run(
                [self.runtime, "image", "inspect", "--format={{.Id}}", image],
                input_data=None,
                timeout=4,
                output_limit=4096,
            )
        except (OSError, subprocess.TimeoutExpired):
            return self._unable(normalized_language, "container_runtime_unavailable")
        if inspected.returncode != 0 or inspected.timed_out:
            return self._unable(normalized_language, "container_image_unavailable")

        results: list[dict[str, Any]] = []
        passed = 0
        deadline = time.monotonic() + self.total_timeout_seconds
        filename = {"python": "main.py", "javascript": "main.js", "java": "Main.java"}[normalized_language]
        try:
            with tempfile.TemporaryDirectory(prefix="subjective-code-") as directory:
                workdir = Path(directory)
                os.chmod(workdir, 0o755)
                source_path = workdir / filename
                source_path.write_text(source, encoding="utf-8")
                os.chmod(source_path, 0o444)
                for index, case in enumerate(cases):
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return self._unable(normalized_language, "total_execution_time_limit")
                    name = f"scoring-{uuid.uuid4().hex[:20]}"
                    cidfile = str(workdir / f"container-{index}.id")
                    command = self._container_command(
                        image, entrypoint, str(workdir), name, cidfile
                    )
                    outcome = self.command_runner.run(
                        command,
                        input_data=case["input"].encode("utf-8"),
                        timeout=min(self.case_timeout_seconds, remaining),
                        output_limit=_MAX_OUTPUT_BYTES,
                        container_name=name,
                    )
                    if outcome.timed_out:
                        matched, reason = False, "time_limit"
                    elif outcome.output_limited:
                        matched, reason = False, "output_limit"
                    elif not outcome.container_started:
                        return self._unable(normalized_language, "container_start_failed")
                    elif outcome.returncode != 0:
                        matched, reason = False, "program_error"
                    else:
                        actual = outcome.stdout.decode("utf-8", errors="replace").replace("\r\n", "\n").rstrip("\n")
                        expected = case["expected_output"].replace("\r\n", "\n").rstrip("\n")
                        matched = actual == expected
                        reason = "output_match" if matched else "output_mismatch"
                    if matched:
                        passed += 1
                    visibility = case["visibility"]
                    results.append({
                        "name": case["name"] if visibility == "public" else f"hidden_case_{index + 1}",
                        "visibility": visibility,
                        "passed": matched,
                        "reason": reason,
                    })
        except (OSError, subprocess.TimeoutExpired):
            return self._unable(normalized_language, "container_runtime_unavailable")
        return {
            "status": "verified",
            "language": normalized_language,
            "passed": passed,
            "total": len(cases),
            "cases": results,
            "reason": None,
        }

    def _container_command(
        self,
        image: str,
        entrypoint: list[str],
        source_dir: str,
        container_name: str,
        cidfile: str,
    ) -> list[str]:
        return [
            self.runtime, "run", "--rm", "--pull=never", "--init", "-i",
            f"--name={container_name}", f"--cidfile={cidfile}",
            "--label=subjective-scoring.sandbox=true",
            "--network=none", "--read-only", "--cap-drop=ALL",
            "--security-opt=no-new-privileges", "--ipc=none",
            "--pids-limit=32", "--memory=256m", "--memory-swap=256m",
            "--cpus=1", "--ulimit=cpu=8:8", "--ulimit=nofile=64:64",
            "--user=65534:65534", "--tmpfs=/tmp:rw,nosuid,nodev,size=32m",
            f"--mount=type=bind,src={source_dir},dst=/submission,readonly",
            "--workdir=/submission", image, *entrypoint,
        ]

    @staticmethod
    def _unable(language: str | None, reason: str) -> dict[str, Any]:
        return {
            "status": "unable_to_verify",
            "language": language,
            "passed": 0,
            "total": 0,
            "cases": [],
            "reason": reason,
        }


def _validate_cases(test_cases: list[dict[str, Any]]) -> list[dict[str, str]]:
    if not isinstance(test_cases, list) or not 2 <= len(test_cases) <= _MAX_CASES:
        raise ValueError("case count out of range")
    cases: list[dict[str, str]] = []
    names: set[str] = set()
    visibilities: set[str] = set()
    for case in test_cases:
        if not isinstance(case, dict):
            raise ValueError("invalid case")
        name = case.get("name")
        visibility = case.get("visibility")
        input_text = case.get("input")
        expected = case.get("expected_output")
        if (
            not isinstance(name, str) or not name.strip() or len(name) > 80
            or name.casefold() in names
            or visibility not in {"public", "hidden"}
            or not isinstance(input_text, str)
            or not isinstance(expected, str)
            or len(input_text.encode("utf-8")) > _MAX_IO_BYTES
            or len(expected.encode("utf-8")) > _MAX_IO_BYTES
            or "\x00" in input_text or "\x00" in expected
        ):
            raise ValueError("invalid case")
        names.add(name.casefold())
        visibilities.add(visibility)
        cases.append({
            "name": name.strip(),
            "visibility": visibility,
            "input": input_text,
            "expected_output": expected,
        })
    if visibilities != {"public", "hidden"}:
        raise ValueError("both public and hidden cases are required")
    return cases


def _docker_environment() -> dict[str, str]:
    allowed = {"PATH", "HOME", "DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"}
    return {key: value for key, value in os.environ.items() if key in allowed}


__all__ = ["BoundedSubprocessRunner", "DockerCodeRunner", "ProcessResult"]
