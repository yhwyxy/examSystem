"""Exercise an actual deployed sandbox through its authenticated protocol."""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

from subjective_scoring.sandbox_transport import HTTPExecutionClient, RemoteCodeRunner, RemoteSQLRunner


def _cases() -> list[dict[str, str]]:
    return [
        {"name": "sample", "visibility": "public", "input": "2 3\n", "expected_output": "5"},
        {"name": "edge", "visibility": "hidden", "input": "-3 7\n", "expected_output": "4"},
    ]


def run_smoke(code_runner: Any, sql_runner: Any) -> dict[str, bool]:
    sources = {
        "python": "a,b=map(int,input().split()); print(a+b)",
        "javascript": "const a=require('fs').readFileSync(0,'utf8').trim().split(/\\s+/).map(Number); console.log(a[0]+a[1]);",
        "java": "import java.util.Scanner; public class Main { public static void main(String[] args) { Scanner s=new Scanner(System.in); System.out.println(s.nextInt()+s.nextInt()); } }",
    }
    outcomes = {}
    for language, source in sources.items():
        report = code_runner.run(source, language, _cases())
        outcomes[language + "_stdin"] = report.get("status") == "verified" and report.get("passed") == 2

    isolation_source = '''import os, socket
assert not any(os.environ.get(k) for k in ("DATABASE_URL", "EXAM_DATABASE_URL", "EXAM_ADMIN_PASSWORD", "LLM_API_KEY", "RERANK_API_KEY", "SANDBOX_AUTH_TOKEN"))
assert not any(os.path.exists(p) for p in ("/app/data", "/app/config.yaml", "/var/run/docker.sock", "/run/docker.sock"))
s = socket.socket()
s.settimeout(0.5)
try:
    s.connect(("1.1.1.1", 80))
except OSError:
    print("isolated")
else:
    print("network_access")
finally:
    s.close()
'''
    isolation_cases = [{**case, "expected_output": "isolated"} for case in _cases()]
    report = code_runner.run(isolation_source, "python", isolation_cases)
    outcomes["network_files_and_credentials_isolated"] = report.get("status") == "verified" and report.get("passed") == 2

    for name, source, reason in (
        ("wall_timeout", "while True: pass", "time_limit"),
        ("output_bound", "print('x'*100000)", "output_limit"),
    ):
        report = code_runner.run(source, "python", _cases())
        outcomes[name] = (report.get("status") == "verified" and report.get("passed") == 0
                          and len(report.get("cases", [])) == 2
                          and all(case.get("reason") == reason for case in report["cases"]))

    def dataset(name, visibility, values):
        return {"name": name, "visibility": visibility, "tables": [{
            "name": "items", "columns": [{"name": "value", "type": "INTEGER"}],
            "rows": [[value] for value in values],
        }]}

    datasets = [dataset("sample", "public", [1, 1, None]), dataset("edge", "hidden", [2, None, 2])]
    report = sql_runner.run("SELECT value FROM items", "SELECT value FROM items", "sqlite", datasets)
    outcomes["sql_duplicates_and_nulls"] = report.status == "verified" and report.passed == 2
    report = sql_runner.run("SELECT value FROM items", "SELECT DISTINCT value FROM items", "sqlite", datasets)
    outcomes["sql_duplicate_mismatch"] = report.status == "verified" and report.passed == 0
    report = sql_runner.run("SELECT value FROM items ORDER BY value DESC",
                            "SELECT value FROM items ORDER BY value ASC", "sqlite", datasets)
    outcomes["sql_order_mismatch"] = report.status == "verified" and report.passed == 0
    report = sql_runner.run("SELECT value FROM items", "DELETE FROM items", "sqlite", datasets)
    outcomes["unconfigured_write_not_verified"] = (report.status == "unable_to_verify"
                                                   and report.reason == "sandbox_unable_to_verify")
    policy = {"mode": "mutation", "mutation_tables": ["items"]}
    for name, statement in (
        ("sql_insert_state", "INSERT INTO items(value) VALUES(5)"),
        ("sql_update_state", "UPDATE items SET value=value+1 WHERE value IS NOT NULL"),
        ("sql_delete_state", "DELETE FROM items WHERE value IS NULL"),
    ):
        report = sql_runner.run(statement, statement, "sqlite", datasets, sql_execution=policy)
        outcomes[name] = report.status == "verified" and report.passed == 2
    return outcomes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", required=True)
    parser.add_argument("--build", required=True)
    args = parser.parse_args()
    try:
        client = HTTPExecutionClient(url=args.url, token=os.environ.get("SANDBOX_AUTH_TOKEN", ""),
                                     expected_build=args.build)
    except ValueError as exc:
        parser.error(str(exc))
    outcomes = run_smoke(RemoteCodeRunner(client), RemoteSQLRunner(client))
    json.dump({"runner_build": args.build, "checks": outcomes, "passed": all(outcomes.values())},
              fp=sys.stdout, indent=2)
    print()
    return 0 if all(outcomes.values()) else 2


if __name__ == "__main__":
    raise SystemExit(main())
