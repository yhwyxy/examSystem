"""Teacher-confirmed SQL execution policy; query mode never enables writes."""

from __future__ import annotations

import re
from typing import Any


def normalize_sql_execution(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) - {"mode", "mutation_tables"}:
        raise ValueError("SQL execution policy must contain only mode and mutation_tables")
    mode = value.get("mode", "query")
    tables = value.get("mutation_tables", [])
    if not isinstance(mode, str) or mode not in {"query", "mutation"} or not isinstance(tables, list) or len(tables) > 50:
        raise ValueError("invalid SQL execution mode or tables")
    names = []
    for table in tables:
        if not isinstance(table, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,62}", table):
            raise ValueError("mutation tables must be SQL identifiers")
        if table.lower() in names:
            raise ValueError("mutation tables must be unique")
        names.append(table.lower())
    if (mode == "mutation" and not names) or (mode == "query" and names):
        raise ValueError("only mutation mode requires a non-empty table allowlist")
    return {"mode": mode, "mutation_tables": names}
