"""Restricted code/SQL verification protocol for a dedicated sandbox host."""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlsplit

from subjective_scoring.engines.code_execution import DockerCodeRunner, _validate_cases
from subjective_scoring.engines.sql_execution import SQLExecutionReport, _validate_dataset
from subjective_scoring.sql_policy import normalize_sql_execution

MAX_REQUEST_BYTES = 3 * 1024 * 1024
MAX_RESPONSE_BYTES = 64 * 1024


def validate_request(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict) or type(payload.get("schema_version")) is not int or payload["schema_version"] != 1:
        raise ValueError("invalid protocol version")
    operation = payload.get("operation")
    common = {"schema_version", "operation"}
    if operation == "code":
        if set(payload) != common | {"source", "language", "test_cases"}:
            raise ValueError("invalid code fields")
        if payload["language"] not in {"python", "javascript", "java"}:
            raise ValueError("unsupported language")
        source = payload["source"]
        if not isinstance(source, str) or not source.strip() or len(source.encode()) > 64 * 1024:
            raise ValueError("invalid source")
        _validate_cases(payload["test_cases"])
    elif operation == "sql":
        fields = common | {"reference_sql", "student_sql", "dialect", "datasets"}
        if set(payload) not in (fields, fields | {"execution"}):
            raise ValueError("invalid SQL fields")
        normalize_sql_execution(payload.get("execution", {}))
        if payload["dialect"] != "sqlite":
            raise ValueError("unsupported dialect")
        for field in ("reference_sql", "student_sql"):
            if not isinstance(payload[field], str) or not 0 < len(payload[field]) <= 10_000:
                raise ValueError("invalid SQL")
        datasets = payload["datasets"]
        if not isinstance(datasets, list) or not 2 <= len(datasets) <= 20:
            raise ValueError("invalid dataset count")
        names = set()
        fixture_bytes = 0
        for dataset in datasets:
            prepared = _validate_dataset(dataset)
            name = prepared["name"].casefold()
            if name in names:
                raise ValueError("duplicate dataset")
            names.add(name)
            fixture_bytes += prepared["fixture_bytes"]
        if fixture_bytes > 2 * 1024 * 1024:
            raise ValueError("fixture size limit")
    else:
        raise ValueError("unsupported operation")
    return payload


def validate_report(payload: dict[str, Any], report: Any) -> dict[str, Any]:
    """Reconstruct only expected result fields; never relay stdout or hidden data."""
    if not isinstance(report, dict):
        raise ValueError("invalid report")
    code = payload["operation"] == "code"
    language_field = "language" if code else "dialect"
    language = payload[language_field]
    if report.get("status") == "unable_to_verify":
        return {
            "status": "unable_to_verify", language_field: language,
            "passed": 0, "total": 0, "cases" if code else "datasets": [],
            "reason": "sandbox_unable_to_verify",
        }
    if report.get("status") != "verified" or report.get(language_field) != language:
        raise ValueError("invalid report status")
    inputs = payload["test_cases" if code else "datasets"]
    entries = report.get("cases" if code else "datasets")
    if type(report.get("total")) is not int or report["total"] != len(inputs):
        raise ValueError("invalid report total")
    if not isinstance(entries, list) or len(entries) != len(inputs):
        raise ValueError("invalid report entries")
    sanitized = []
    passed = 0
    for index, (case, entry) in enumerate(zip(inputs, entries)):
        if not isinstance(entry, dict) or type(entry.get("passed")) is not bool:
            raise ValueError("invalid case outcome")
        matched = entry["passed"]
        allowed_reasons = (
            {"output_mismatch", "program_error", "time_limit", "output_limit"}
            if code else {"result_mismatch", "student_query_time_limit", "student_result_limit", "student_query_error"}
        )
        mutation = not code and payload.get("execution", {}).get("mode") == "mutation"
        success_reason = "output_match" if code else ("state_match" if mutation else "result_match")
        if mutation:
            allowed_reasons.discard("result_mismatch")
            allowed_reasons.add("state_mismatch")
        if ((matched and entry.get("reason") != success_reason)
                or (not matched and entry.get("reason") not in allowed_reasons)):
            raise ValueError("inconsistent case reason")
        passed += matched
        visibility = case.get("visibility", "hidden")
        item = {
            "name": case["name"] if visibility == "public" else f"hidden_case_{index + 1}",
            "visibility": visibility, "passed": matched, "reason": entry["reason"],
        }
        if not code:
            for field in ("expected_rows", "actual_rows"):
                value = entry.get(field)
                if value is None and field == "actual_rows":
                    item[field] = None
                elif type(value) is int and 0 <= value <= 5000:
                    item[field] = value
                else:
                    raise ValueError("invalid result row count")
        sanitized.append(item)
    if type(report.get("passed")) is not int or report["passed"] != passed:
        raise ValueError("invalid passed count")
    return {
        "status": "verified", language_field: language, "passed": passed,
        "total": len(inputs), "cases" if code else "datasets": sanitized, "reason": None,
    }


class HTTPExecutionClient:
    def __init__(self, *, url: str, token: str, expected_build: str, client: Any | None = None) -> None:
        parts = urlsplit(url)
        loopback = parts.hostname in {"localhost", "127.0.0.1", "::1"}
        if (parts.scheme != "https" and not (parts.scheme == "http" and loopback)) or not parts.hostname:
            raise ValueError("sandbox URL requires HTTPS or loopback HTTP")
        if parts.username or parts.password or parts.query or parts.fragment or parts.path not in {"", "/"}:
            raise ValueError("sandbox URL must be an origin without credentials")
        if not isinstance(token, str) or len(token) < 32 or "\n" in token or "\r" in token:
            raise ValueError("sandbox token must contain at least 32 characters")
        if not isinstance(expected_build, str) or not expected_build.strip() or len(expected_build) > 128:
            raise ValueError("sandbox build must be specified")
        self.url = url.rstrip("/")
        self._token = token
        self.expected_build = expected_build
        self._client = client

    def __repr__(self) -> str:
        return f"HTTPExecutionClient(expected_build={self.expected_build!r})"

    def execute(self, payload: dict[str, Any]) -> dict[str, Any]:
        import httpx

        validate_request(payload)
        body = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode()
        if len(body) > MAX_REQUEST_BYTES:
            raise ValueError("sandbox request size limit")
        client = self._client or httpx.Client(timeout=70, trust_env=False, follow_redirects=False)
        try:
            with client.stream(
                "POST", self.url + "/v1/execute", content=body,
                headers={"Authorization": "Bearer " + self._token, "Content-Type": "application/json"},
                timeout=70, follow_redirects=False,
            ) as response:
                if response.status_code != 200:
                    raise ValueError("sandbox request failed")
                raw = bytearray()
                for chunk in response.iter_bytes():
                    raw.extend(chunk)
                    if len(raw) > MAX_RESPONSE_BYTES:
                        raise ValueError("sandbox response size limit")
            envelope = json.loads(raw)
            if not isinstance(envelope, dict) or envelope.get("schema_version") != 1:
                raise ValueError("invalid sandbox envelope")
            if envelope.get("runner_build") != self.expected_build:
                raise ValueError("sandbox build mismatch")
            report = validate_report(payload, envelope.get("report"))
            report["runner_build"] = self.expected_build
            return report
        finally:
            if self._client is None:
                client.close()


class RemoteCodeRunner:
    def __init__(self, client: HTTPExecutionClient) -> None:
        self.client = client

    def run(self, source: str, language: str | None, test_cases: list[dict[str, Any]]) -> dict[str, Any]:
        try:
            return self.client.execute({
                "schema_version": 1, "operation": "code", "source": source,
                "language": (language or "").lower(), "test_cases": test_cases,
            })
        except Exception:
            # Neither provider bodies nor transport errors may include submitted code or secrets.
            return DockerCodeRunner._unable(language, "sandbox_transport_unavailable")


class RemoteSQLRunner:
    def __init__(self, client: HTTPExecutionClient) -> None:
        self.client = client

    def run(self, reference_sql: str, student_sql: str, dialect: str | None,
            datasets: list[dict[str, Any]], sql_execution: dict[str, Any] | None = None) -> SQLExecutionReport:
        try:
            report = self.client.execute({
                "schema_version": 1, "operation": "sql", "reference_sql": reference_sql,
                "student_sql": student_sql, "dialect": dialect, "datasets": datasets,
                **({"execution": sql_execution} if sql_execution is not None else {}),
            })
            return SQLExecutionReport(**report)
        except Exception:
            return SQLExecutionReport("unable_to_verify", dialect, 0, 0, [], "sandbox_transport_unavailable")
